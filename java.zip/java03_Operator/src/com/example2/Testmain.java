package com.example2;


public class Testmain {

	public static void main(String[] args) {
		
		CastingSample CS = new CastingSample();
	//	CS.printUnicode();
		CS.calculatorScore();
	
	}
}
