package com.example;

public class Testmain {

	public static void main(String[] args) {
		Example ex1 = new Example();
	//		ex1.example1();     
	//		ex1.example2();
	//		ex1.example3();
	}
}
