package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import com.biz.MyBiz;
import com.dto.memberDto;

@WebServlet("/logRei.do")
public class logRei extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public logRei() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String cd = request.getParameter("cd");
		
		if(cd.equals("login")) {
			String id = request.getParameter("id");
			String pw = request.getParameter("pw");
			
//			memberDto dto = loginDao.login(id,pw);
			
//			if(dto.getMid() != null){
//				
//			}else{
//	
//			}
		}else if(cd.equals("logout")) {
			
			
			
			
		//regist부분에서 submit 눌렀을 때	
		}else if(cd.equals("register")) {
			memberDto dto = (memberDto)request.getAttribute("dto");
			
			System.out.println("넣은 이름: "+ dto.getMname());
			
			String mid = dto.getMid();
			memberDto origindto =  MyBiz.selectUser(mid);
			
			boolean valid = false;
			if(origindto == null) {
				valid = true;	//가입 가능
			}
			
			if(valid) {
			 boolean boolchk = MyBiz.insertUser(dto);
			 
			 request.setAttribute("valid", valid);
			 request.setAttribute("boolchk", boolchk);
			 
			 if(valid && boolchk) {
				 PrintWriter out = response.getWriter();
				 out.println("<script type='text/javascript'>alert('가입 축하합니다.');</script>");
				 response.sendRedirect("login_resist_form.jsp");
			 }
			}else {
				response.sendRedirect("login_resist_form.jsp");
			}
			
		//id중복여부 체크부분	
		}else if(cd.equals("idchk")) {
			String mid = (String)request.getAttribute("mid");
			
			String res = MyBiz.idChk(mid);
			boolean idnotused = true;
			
			if(res != null){
				idnotused = false;
			}
			
			System.out.println("res : "+ res);
			System.out.println("idnotused : " + idnotused);
			
			JSONObject obj = new JSONObject();
			obj.put("idnotused", idnotused);
			
			
			PrintWriter out = response.getWriter();
			out.println(obj.toJSONString());
			
			
			System.out.println(obj.toJSONString());
			
			
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
