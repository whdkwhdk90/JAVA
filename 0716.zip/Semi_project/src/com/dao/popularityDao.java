package com.dao;

public class popularityDao {

	
	//selecttot, se 
}
