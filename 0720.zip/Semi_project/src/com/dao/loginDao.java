package com.dao;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dto.memberDto;

public class loginDao {

	public memberDto login(String id, String pw) {
		Connection con = getConnection();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		memberDto res = new memberDto();
		String sql = " 	SELECT * FROM MEMBER WHERE M_ID=? AND M_PW=? ";
		
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, id);
			pstm.setString(2, pw);
			System.out.println("03. query 준비 "+ sql);
			
			rs = pstm.executeQuery();
			System.out.println("04. query 실행 및 리턴");
			
			while(rs.next()) {
				res.setMno(rs.getInt(1));
				res.setMid(rs.getString(2));
				res.setMpw(rs.getString(3));
				res.setMname(rs.getString(4));
				res.setPhone(rs.getString(5));
				res.setAge(rs.getInt(6));
				res.setGender(rs.getString(7));
				res.setResidence(rs.getString(8));
				
			}
		} catch (SQLException e) {
			System.out.println("3/4단계 에러");
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstm);
			System.out.println("05. db 종료 \n");
		}
		return res;
	}
	

	public memberDto selectUser(String mid,Connection con) {
		PreparedStatement pstm = null;
		ResultSet rs = null;
		memberDto res = null;
		String sql = "SELECT * FROM MEMBER WHERE M_ID=? "; 
		
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, mid);
			System.out.println("03. query 준비 : "+ sql);
			
			rs = pstm.executeQuery();
			System.out.println("04. query 실행 및 리턴");
			
			while(rs.next()) {
				res = new memberDto(
				rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),
				rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8)
						);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstm);
		}
		return res;
	}


	public static String idChk(String mid,Connection con) {
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String res = null;
		String sql = " SELECT * FROM MEMBER WHERE M_ID=? ";
		
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, mid);
			
			rs = pstm.executeQuery();
			
			while(rs.next()) {
				res = rs.getString(2);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstm);
		}
		return res;
	}
	
	
	public int insertUser(memberDto dto,Connection con) {
		int res = 0;
		PreparedStatement pstm = null;
		String sql = " INSERT INTO MEMBER VALUES(MEMBERSEQ.NEXTVAL,?,?,?,?,?,?,?) ";
		
		try {
			System.out.println(dto.toString());
			pstm = con.prepareStatement(sql);
			pstm.setString(1, dto.getMid());
			pstm.setString(2, dto.getMpw());
			pstm.setString(3, dto.getMname());
			pstm.setString(4, dto.getPhone());
			pstm.setInt(5, dto.getAge());
			pstm.setString(6, dto.getGender());
			pstm.setString(7, dto.getResidence());

			res = pstm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstm);
		}
		return res;
	}

	
	
}
