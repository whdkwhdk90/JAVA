package com.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.dao.foodDao;
import com.dao.loginDao;
import com.dao.memberDao;
import com.dao.popularityDao;
import com.dto.memberDto;

import static common.JDBCTemplate.*;

public class MyBiz{

	private memberDao ddao = new memberDao();
	private popularityDao pdao = new popularityDao();
	private foodDao fdao = new foodDao();
	private static loginDao ldao = new loginDao();
	
//-----------------------------------------------------------------------------
	
//--------------------------member-----------------------------------------------
	
	public int insert(memberDto member) {
		return ddao.insert(member);
	}
	public memberDto selectOne(int mno) {
		return ddao.selectOne(mno);
	}
	
//------------------------------------------------------------------------------
	
	
	
//-------------------------------popularity----------------------------------------	
	
	
	
	
//------------------------------------------------------------------------------	
	

	
//------------------------------food-----------------------------------------------	
	
	
//------------------------------------------------------------------------------	
		
	
//------------------------------login/regist-----------------------------------------------	
	
	
	
	//id체크 Biz
	public static memberDto selectUser(String mid) {
		Connection con = getConnection();
		memberDto dto = ldao.selectUser(mid,con);
		
		try {
			close(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	
	public static String idChk(String id) {
		
		Connection con = getConnection();
		String res = ldao.idChk(id,con);
		
		try {
			close(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}
	
	
	
	
	
	
	//회원 가입 Biz
	public static boolean insertUser(memberDto dto) {
		Connection con = getConnection();
		boolean valid = false;
		
		int res = ldao.insertUser(dto,con);
		
		if(res>0) {
			commit(con);
			valid = true;
		}
			
		try {
			close(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return valid;
	}
	public static memberDto login(String id, String pw) {
		Connection con = getConnection();
		memberDto dto = ldao.login(id, pw);
		
		try {
			close(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	
	
	
	
//------------------------------------------------------------------------------	
			
			
	
	
}
