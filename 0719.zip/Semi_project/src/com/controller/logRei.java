package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;

import com.biz.MyBiz;
import com.dto.memberDto;

@WebServlet("/logRei.do")
public class logRei extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public logRei() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String cd = request.getParameter("cd");
		
		if(cd.equals("login")) {
			memberDto dto = (memberDto)request.getAttribute("dto");
			
			String id = dto.getMid();
			String pw = dto.getMpw();
			
			memberDto chkdto = MyBiz.login(id,pw);
			String name = chkdto.getMname();
			//chkdto가 있는 경우 실행하겠다
			if(chkdto != null) {
				//로그인 성공
				System.out.println("로그인 성공");
				HttpSession session = request.getSession(true);
				session.setAttribute("name",name);
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> window.opener.location= 'main.jsp'; self.close(); </script>");
				
			}else {
				System.out.println("로그인 실패");
				PrintWriter out = response.getWriter();
				out.println("<script> alert('로그인 실패하셨습니다. 다시입력해주세요.'); location.href='login_resist_form.jsp'; </script>");
			}
			
			
		}else if(cd.equals("logout")) {
			
			
			
			
		//regist부분에서 submit 눌렀을 때	
		}else if(cd.equals("register")) {
			memberDto dto = (memberDto)request.getAttribute("dto");
			
			String mid = dto.getMid();
			//기존 고객있는지 재확인
			memberDto origindto =  MyBiz.selectUser(mid);
			
			boolean valid = false;
			
			if(origindto == null) {
				valid = true;	//가입 가능
				
				//db 삽입
				boolean insertchk = MyBiz.insertUser(dto);
				
				if(insertchk) {
					PrintWriter out = response.getWriter();
					out.println("<script> alert('가입 축하합니다.'); location.href='login_resist_form.jsp';</script>");
				}else {
					PrintWriter out = response.getWriter();
					out.println("<script> alert('가입 실패.'); location.href='login_resist_form.jsp'; </script>");
				}
			}
			
		//id중복여부 체크부분	
		}else if(cd.equals("idchk")) {
			
			String id = (String)request.getAttribute("mid");
			
			String res = MyBiz.idChk(id);
			
			boolean idnotused = true;
			
			if(res != null){
				idnotused = false;
			}
			
			System.out.println("res : "+ res);
			System.out.println("idnotused : " + idnotused);
			
			JSONObject obj = new JSONObject();
			obj.put("idnotused", idnotused);
			
			PrintWriter out = response.getWriter();
			out.println(obj.toJSONString());
			
			System.out.println("json의 key : value 값  = "+obj.toJSONString());
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
