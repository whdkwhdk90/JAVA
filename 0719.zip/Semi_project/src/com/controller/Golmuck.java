package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.memberDto;

@WebServlet("/golmuck.do")
public class Golmuck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Golmuck() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String cd = request.getParameter("cd");
		System.out.println("cd : " + cd);
		if(cd.equals("agender")) {
			response.sendRedirect("ageGender.do?cd=agender");
		}else if(cd.equals("cook")) {
			response.sendRedirect("cook.do?cd=cook");
		}else if(cd.equals("total")) {
			response.sendRedirect("total.do?cd=total");
		}else if(cd.equals("nation")) {
			response.sendRedirect("nation.do?cd=nation");
		}else if(cd.equals("mapSms")) {
			response.sendRedirect("mapsms.do?cd=mapsms");
		}else if(cd.equals("main")) {
			response.sendRedirect("main.jsp");
		}else if(cd.equals("issue")) {
			response.sendRedirect("issue.jsp");
		}else if(cd.equals("login")) {
			String id = request.getParameter("lid");
			String pw = request.getParameter("lpw");
			
			memberDto dto = new memberDto();
			dto.setMid(id);
			dto.setMpw(pw);
			
			request.setAttribute("dto", dto);
			RequestDispatcher dispatch = request.getRequestDispatcher("logRei.do?cd=login");
			dispatch.forward(request, response);
			
			//regist에서 submit눌렀을 때 
		}else if(cd.equals("register")) {
			
			memberDto dto = new memberDto();
			String mid = request.getParameter("id");
			String mpw = request.getParameter("pw");
			String mname = request.getParameter("name");
			String phone = request.getParameter("phone");
			int age = Integer.parseInt(request.getParameter("age"));
			String gender = request.getParameter("chk");
			String residence1 = request.getParameter("residence1");
			String residence2 = request.getParameter("residence2");
			String residence = residence1.concat((" ").concat(residence2));
			dto.setMid(mid);
			dto.setMpw(mpw);
			dto.setMname(mname);
			dto.setPhone(phone);
			dto.setAge(age);
			dto.setGender(gender);
			dto.setResidence(residence);
			
			request.setAttribute("dto", dto);
			RequestDispatcher dispatch = request.getRequestDispatcher("logRei.do?cd=register");
			dispatch.forward(request, response);
			
			//regist에서 idchk하는 부분
		}else if(cd.equals("idchk")) {
			
			String mid = request.getParameter("id");
			
			System.out.println("golmuck id : " + mid);
			
			request.setAttribute("mid", mid);
			RequestDispatcher dispatch = request.getRequestDispatcher("logRei.do?cd=idchk");
			dispatch.forward(request, response);
			
		}
			
		
		
		
	}
		

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
