package firstproject.com.test;

public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello World!!");
		System.out.println("점심 시간이 다가옵니다. ");
		System.out.println("배가고프네요. ");
		
	}

}

// 한줄 주석
/* 여러
*  줄
*  주석 *은 있어도 없어도 됨
*/