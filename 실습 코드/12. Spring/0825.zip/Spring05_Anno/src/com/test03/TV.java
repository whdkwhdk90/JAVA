package com.test03;

public interface TV {
	void powerOn();
	void powerOff();
	void volUp();
	void volDown();
}
