package com.test03;

import org.springframework.stereotype.Component;

@Component
public class LgTV implements TV{

	@Override
	public void powerOn() {
		System.out.println("LgTV power on");
	}

	@Override
	public void powerOff() {
		System.out.println("LgTV power off");		
	}

	@Override
	public void volUp() {
		System.out.println("LgTV volume up");		
	}

	@Override
	public void volDown() {
		System.out.println("LgTV volume down");		
	}

}
