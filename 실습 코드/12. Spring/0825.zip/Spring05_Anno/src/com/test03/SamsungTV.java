package com.test03;

import org.springframework.stereotype.Component;

//component의 이름을 안정하면 samsungTV로 만들어지지만 뒤에 명시를 하면 그 이름으로 bean 설정
@Component("samsung")
public class SamsungTV implements TV{

	@Override
	public void powerOn() {
		System.out.println("SamsungTV power on");
	}

	@Override
	public void powerOff() {
		System.out.println("SamsungTV power off");		
	}

	@Override
	public void volUp() {
		System.out.println("SamsungTV volume up");		
	}

	@Override
	public void volDown() {
		System.out.println("SamsungTV volume down");		
	}

}
