package com.test01.anno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MTest {
	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("com/test01/anno/applicationContext.xml");
		
		//bean을 따로 만들지 않았지만 클래스 이름의 첫글자를 소문자로 바꾸고 id자리에 넣는다.
		MyNickNamePrn myNick = factory.getBean("myNickNamePrn",MyNickNamePrn.class);
		System.out.println(myNick);
	}
	
}
