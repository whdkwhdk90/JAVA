package com.test01.anno;

import org.springframework.stereotype.Component;

@Component
public class NickName {
	@Override
	public String toString() {
		return "바다거북이";
	}
	
	
}
