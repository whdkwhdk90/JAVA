package com.test01;

public class NickName {
	@Override
	public String toString() {
		return "바다거북이";
	}
	
	
}
