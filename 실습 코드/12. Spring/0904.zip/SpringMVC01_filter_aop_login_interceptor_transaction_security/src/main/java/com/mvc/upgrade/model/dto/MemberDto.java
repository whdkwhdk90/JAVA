package com.mvc.upgrade.model.dto;

public class MemberDto {

	private int memberno;
	private String memberid;
	private String memberpw;
	private String membername;
	
	
	public MemberDto() {
		// TODO Auto-generated constructor stub
	}


	public MemberDto(int memberno, String memberid, String memberpw, String membername) {
		super();
		this.memberno = memberno;
		this.memberid = memberid;
		this.memberpw = memberpw;
		this.membername = membername;
	}


	public int getMemberno() {
		return memberno;
	}


	public void setMemberno(int memberno) {
		this.memberno = memberno;
	}


	public String getMemberid() {
		return memberid;
	}


	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}


	public String getMemberpw() {
		return memberpw;
	}


	public void setMemberpw(String memberpw) {
		this.memberpw = memberpw;
	}


	public String getMembername() {
		return membername;
	}


	public void setMembername(String membername) {
		this.membername = membername;
	}
	
	
	
	
	
	
	
	
}
