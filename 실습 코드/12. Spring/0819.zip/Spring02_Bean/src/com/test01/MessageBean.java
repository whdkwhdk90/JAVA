package com.test01;

public interface MessageBean {
	public void sayHello();
}
