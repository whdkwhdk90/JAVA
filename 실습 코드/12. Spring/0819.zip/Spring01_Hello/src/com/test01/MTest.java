package com.test01;

public class MTest {

	public static void main(String[] args) {
		MessageBean bean = new MessageBean();
		bean.sayHello("Spring");
		
	}
}
