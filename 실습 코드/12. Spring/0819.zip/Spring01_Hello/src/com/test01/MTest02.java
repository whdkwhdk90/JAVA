package com.test01;

public class MTest02 {

	public static void main(String[] args) {

	}

}
