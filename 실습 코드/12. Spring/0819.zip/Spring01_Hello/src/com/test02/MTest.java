package com.test02;

public class MTest {

	public static void main(String[] args) {
		MessageBean bean = new MessageBeanEn();
		//동적 바인딩
		bean.sayHello("Spring");
		
		bean = new MessageBeanKo();
		//동적 바인딩 : 실제 주소는 부모객체에 있지만 자식객체로 실행됨.
		bean.sayHello("스프링");
		
		
	}

}
