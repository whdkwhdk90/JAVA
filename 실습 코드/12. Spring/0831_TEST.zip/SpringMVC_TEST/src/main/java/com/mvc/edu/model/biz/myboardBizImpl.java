package com.mvc.edu.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mvc.edu.model.dao.myboardDaoImpl;
import com.mvc.edu.model.dto.myboardDto;

@Service
public class myboardBizImpl implements myboardBiz{

	@Autowired
	private myboardDaoImpl dao;
	
	@Override
	public List<myboardDto> selectList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public myboardDto selectOne() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(myboardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(myboardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int myno) {
		// TODO Auto-generated method stub
		return 0;
	}

}
