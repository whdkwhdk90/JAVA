package com.mvc.edu.model.dao;

import java.util.List;

import com.mvc.edu.model.dto.myboardDto;

public interface myboardDao {

	String namespace = "myboard.";
	
	public List<myboardDto> selectList();
	public myboardDto selectOne();
	public int insert(myboardDto dto);
	public int update(myboardDto dto);
	public int delete(int myno);	
}
