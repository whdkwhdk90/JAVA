package com.mvc.edu.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mvc.edu.model.dto.myboardDto;

@Repository
public class myboardDaoImpl implements myboardDao{

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public List<myboardDto> selectList() {
		
		return null;
	}

	@Override
	public myboardDto selectOne() {
		
		return null;
	}

	@Override
	public int insert(myboardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(myboardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int myno) {
		// TODO Auto-generated method stub
		return 0;
	}

}
