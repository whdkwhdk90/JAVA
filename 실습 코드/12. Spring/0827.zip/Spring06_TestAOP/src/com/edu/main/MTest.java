package com.edu.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.edu.entity.Shape;

public class MTest {
	public static void main(String[] args) {
		ApplicationContext factory = 
				new ClassPathXmlApplicationContext("com/edu/main/applicationContext.xml");
		
		
		Shape rect = factory.getBean("rect",Shape.class);
		Shape tri = factory.getBean("tri",Shape.class);
		
		rect.viewSize();
		tri.viewSize();
		
		//도형의 넓이를 구한다.
		//사각형의 넓이 : 15
		//도형의 넓이를 출력한다.
		//------
		//도형의 넓이를 구한다.
		//삼각형의 넓이 : 7
		//도형의 넓이를 출력한다.
		
		
	}
}
