package com.test04;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	
	// 		void일때는 execution과 일치하는 메소드가 실행되기 전에 실행되는건데 String으로 변경하면 나옴.
	@Before("execution(public String *(..))")
	public void before(JoinPoint join) {
		System.out.println("출석카드를 찍는다.");
	}

	@AfterThrowing("execution(public * *(..))")
	public void throwing(JoinPoint join) {
		System.out.println("쉬는 날이었다.");
	}

	//returning의 returnVal이랑 Object의 returnVal이랑 같아야함.
	@AfterReturning(pointcut="execution(public * *(..))", returning="returnVal")
	public void returning(JoinPoint join, Object returnVal) {
		System.out.println(returnVal+"공부하는 날이었다.");
	}
	
	@After("execution(public * com.test04.*.*(..))")
	public void after(JoinPoint join) {
		System.out.println("집에 간다.");
	}
}

// 정상:  before - 메인 - after - afterReturning
// 예외발생 : before - 메인 - after - afterThrowing
