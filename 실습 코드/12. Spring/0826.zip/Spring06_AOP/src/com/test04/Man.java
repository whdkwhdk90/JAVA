package com.test04;

public class Man implements Person{

	@Override
	public String classWork() {
		String s = null;
		s.length();
		System.out.println("컴퓨터를 켜서 이클립스를 실행한다.");
		return "스프링";
	}

	
	
}
