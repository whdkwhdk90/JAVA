package com.test04;

public interface Person {
	String classWork();
}
