package com.test02;

public class Woman implements Person{

	@Override
	public void classWork() {
		System.out.println("컴퓨터를 켜서 책을 본다");
	}

}
