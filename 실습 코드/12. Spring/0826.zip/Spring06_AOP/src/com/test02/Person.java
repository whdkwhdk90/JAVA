package com.test02;

public interface Person {
	void classWork();
}
