package com.test03;

public interface Person {
	void classWork();
}
