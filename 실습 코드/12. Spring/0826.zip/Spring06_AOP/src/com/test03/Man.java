package com.test03;

public class Man implements Person{

	@Override
	public void classWork() {
		System.out.println("컴퓨터를 켜서 이클립스 실행한다.");
	}
	
}
