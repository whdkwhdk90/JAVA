package com.test03;

public class Woman implements Person{

	@Override
	public void classWork() {
		System.out.println("이클립스를 켜서 책을 본다.");
	}

}
