package com.edu.mvc.model.dao;

import java.util.List;

import com.edu.mvc.model.dto.boardDto;

public interface boardDao {
String NAMESPACE ="board.";
	
	public List<boardDto> selectList();
	public boardDto selectOne(int myno);
	public int insert(boardDto dto);
	public int update(boardDto dto);
	public int delete(int myno);
}
