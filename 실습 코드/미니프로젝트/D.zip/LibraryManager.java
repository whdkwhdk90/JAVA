package project.controller;

import java.awt.GridLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;

import project.Model.Book;
import project.Model.Member;

public class LibraryManager {
	private ArrayList<Book> bookList = new ArrayList<>();
	private ArrayList<Member> memberList = new ArrayList<>();
	private ArrayList<Book> lendList = new ArrayList<>();
	private ArrayList<Member> delayList = new ArrayList<>();
	private ArrayList<String> lendTime = new ArrayList<>();
	private Date date = null;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private String name, pnum, title;
	private Member member;

	public ArrayList<Book> getBookList() {
		return bookList;
	}

	public void setBookList(ArrayList<Book> bookList) {
		this.bookList = bookList;
	}

	public ArrayList<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(ArrayList<Member> memberList) {
		this.memberList = memberList;
	}

	public ArrayList<Book> getLendList() {
		return lendList;
	}

	public void setLendList(ArrayList<Book> lendList) {
		this.lendList = lendList;
	}

	public ArrayList<Member> getDelayList() {
		return delayList;
	}

	public void setDelayList(ArrayList<Member> delayList) {
		this.delayList = delayList;
	}

	public LibraryManager() {
		memberList.add(new Member("홍길동", "8405"));
		memberList.add(new Member("아무개", "4333"));
		bookList.add(new Book("이순신", "거북선", 13000));
		bookList.add(new Book("이우진", "노인과 바다", 17000));
	}

	public void addBook(String author, String title, int price) {
		bookList.add(new Book(author, title, price));
		System.out.println("정상적으로 추가되었습니다.");

	}

	public void changeBook() {
		int num1 = 0;

		// 도서 삭제

		// 도서 수정
		bookList();

	}

	public void deleteBook() {

		JFrame mf = new JFrame();
		JLabel label = null;

		mf.setTitle("책리스트");
		mf.setLayout(new GridLayout(bookList.size(), 1));
		mf.setLocation(600, 150);
		mf.setSize(650, 650);
		mf.setResizable(false);
		for (int i = 0; i < bookList.size(); i++) {
			label = new JLabel(bookList.get(i).toString());
			mf.add(label);
		}
		int num = 0;

		System.out.print("삭제하실 번호를 선택하세요: ");
		bookList.remove(num);
		System.out.println("정상적으로 삭제되었습니다.");
	}

	public void reviseBook() {

	}

	public int loanBook(int num, String name, String pnum) {

		int res = 0;
		date = new Date();
		// 대여 및 반납창에서
		// num == 1 이면 대여창
		if (num == 1) {
			for (int i = 0; i < memberList.size(); i++) {
				if (!(memberList.get(i).getName().equals(name) && memberList.get(i).getPnum() == pnum)) {
					res = 1;
				}
			}
			// num2 == 2이면 반납창.
		} else if (num == 2) {
			for (int i = 0; i < memberList.size(); i++) {
				if (memberList.get(i).getName().equals(name) && memberList.get(i).getPnum() == pnum) {
					res = 1;
				} else {
					res = 0;
				}
			}
		}
		this.name = name;
		this.pnum = pnum;
		return res;
	}

	public int loanBook2(int num2, String title) {
		ArrayList<Book> bArr = new ArrayList<Book>();
		Calendar cal = Calendar.getInstance();
		Book book = null;
		String returntime = "";
		int res2 = 2;

		if (num2 == 1) {
			for (int i = 0; i < bookList.size(); i++) {
				if (bookList.get(i).getTitle().equals(title)) {
					book = bookList.get(i);
					bookList.get(i).setCount(book.getCount() + 1);
					bArr.add(book);
					res2 = 1;
				}
			}
			if (book == null) {
				res2 = 0;
			}
			cal.setTime(date);
			cal.add(Calendar.DATE, 3);
			returntime = sdf.format(cal.getTime());
			lendTime.add(returntime);
			System.out.println(lendTime);
			for (int i = 0; i < memberList.size(); i++) {
				if ((memberList.get(i).getName().equals(this.name) && memberList.get(i).getPnum().equals(this.pnum))) {
					member = memberList.get(i);
				}
			}
			if (member != null) {
				for (int i = 0; i < memberList.size(); i++) {
					if ((memberList.get(i).getName().equals(this.name)
							&& memberList.get(i).getPnum().equals(this.pnum))) {
						memberList.get(i).setTitleList(bArr);
						memberList.get(i).setLendTime(lendTime);
					}
				}
			} else {
				memberList.add(new Member(this.name, lendTime, this.pnum, bArr));
			}

			System.out.println(memberList);
			lendList.addAll(bArr);

		} else if (num2 == 2) {
			for (int i = 0; i < lendList.size(); i++) {
				if (lendList.get(i).getTitle().equals(title)) {
					lendList.remove(i);
					res2 = 3;
				} else {
					res2 = 4;
				}
			}
		}
		return res2;
	}

	public void searchBook() {

//		int number = 0;
//		int num =0;
//		if (num == 1) {
//
//			// 책 전체리스트 출력 (저자,책이름,가격 )
//			for (int i = 0; i < bookList.size(); i++) {
//				System.out.println(bookList.get(i).toString());
//			}
//
//			// 책제목으로 검색
//			System.out.print("조회할 책이름: ");
//			String bname = sc.nextLine();
//
//			for (int i = 0; i < bookList.size(); i++) {
//
//				if (bookList.get(i).getTitle().equals(bname)) {
//					System.out.println(bookList.get(i));
//					number = 1;
//				}
//			}
//
//			if (number == 0) {
//				System.out.println("조회할 책이 없습니다.");
//			}
//
//		} else if (num == 2) {
//
//			// 고객정보 전체 출력
//
//			for (Member mlist : memberList) {
//				System.out.println(mlist);
//			}
//
//			// 고객 검색 후 고객정보,대여중인 책
//
//			System.out.print("조회할 회원명: ");
//			String name = sc.next();
//
//			for (int i = 0; i < memberList.size(); i++) {
//				if (memberList.get(i).getName().equals(name)) {
//					System.out.println(memberList.get(i));
//					for(int j=0;j<memberList.get(i).getTitleList().size();j++) {
//						if(!memberList.get(i).getTitleList().isEmpty()) {
//							System.out.println("빌린책: "+memberList.get(i).getTitleList().get(j).getTitle());	
//						}
//						else
//							System.out.println("빌린책이 없습니다.");
//					}
//				}
//				else
//					System.out.println("일치하는 회원명이 존재하지 않습니다.");
//			}
//		}
	}

	public void searchMember() {
	}

	public void weekBook() {

		int max = lendList.get(0).getCount();
		int max2 = lendList.get(0).getCount();
		int max3 = lendList.get(0).getCount();

		for (int i = 0; i < lendList.size(); i++) {
			System.out.println(lendList.get(i));
		}
		// 단순 확인 용도 for문

		int a = 0;
		int b = 0;
		int c = 0;

		for (int i = 0; i < lendList.size(); i++) {
			if (max < lendList.get(i).getCount()) {
				max = lendList.get(i).getCount();
				a = i;
			}
		}

		for (int i = 0; i < lendList.size(); i++) {
			if (max2 < max && max2 < lendList.get(i).getCount()
					&& !lendList.get(i).getTitle().equals(lendList.get(a).getTitle())) {
				max2 = lendList.get(i).getCount();
				b = i;
			}
		}

		for (int i = 0; i < lendList.size(); i++) {
			if (max3 < max2 && max3 < max && max3 < lendList.get(i).getCount()
					&& !lendList.get(i).getTitle().equals(lendList.get(a).getTitle())
					&& !lendList.get(i).getTitle().equals(lendList.get(b).getTitle())) {
				max3 = lendList.get(i).getCount();
				c = i;
			}
		}

		System.out.println("금주의 책(동률 시 가나다 순)");
		System.out.println("1위 : " + lendList.get(a).getTitle() + " " + lendList.get(a).getCount() + "회");
		System.out.println("2위 : " + lendList.get(b).getTitle() + " " + lendList.get(b).getCount() + "회");
		System.out.println("3위 : " + lendList.get(c).getTitle() + " " + lendList.get(c).getCount() + "회");
	}

	public String overdueBook() {

		// 연체도서 목록
		String str = "";
		int fee = 0;
		Calendar cal = Calendar.getInstance();
		try {

			Date currentTime = cal.getTime(); // 현재 날짜
			for (int i = 0; i < memberList.size(); i++) {
				if (!memberList.get(i).getTitleList().isEmpty()) {
					for (int j = 0; j < memberList.get(i).getLendTime().size(); j++) {
						Date lendTime = sdf.parse(memberList.get(i).getLendTime().get(j));
						// 현재 날짜의 +3일
						long DateSub = lendTime.getTime() - currentTime.getTime();
						long DateSubDays = DateSub / (1000 * 60 * 60 * 24);
						if (lendTime.getTime() < currentTime.getTime()) {
							// 반납 예정일이 현재 날짜보다 작으면 연체임
							for (int k = 0; k < memberList.get(i).getTitleList().size(); k++) {
								//
								str += memberList.get(i).getName() + "\t" + memberList.get(i).getPnum() + "\t"
										+ memberList.get(i).getTitleList().get(j).getTitle() + "\t"
										+ sdf.format(lendTime) + "\t" + fee + "\n";
							}
							fee = (int) Math.abs(DateSubDays) * 100;
							memberList.get(i).setFee(fee);
							delayList.add(memberList.get(i));
						}
					}

				}
			}
			System.out.println(delayList);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return str;
	}

	public void bookList() {
		for (int i = 0; i < bookList.size(); i++) {
			System.out.println((i + 1) + "번: " + bookList.get(i));

		}
	}
}
