package project.view;

import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import project.Model.Member;
import project.controller.LibraryManager;

public class OverdueBookList_GUI extends JFrame {

	private static final long serialVersionUID = 1L;

	public OverdueBookList_GUI(LibraryManager lm) {

		System.out.println(lm.hashCode());
		this.setTitle("연체 목록");
		this.setLocation(500, 150);
		try {
			this.setIconImage(ImageIO.read(new File("images/book.png")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		JLabel name_label = new JLabel("이름");
		JLabel pNum_label = new JLabel("전화번호");
		JLabel due_label = new JLabel("반납기한");
		JLabel fee_label = new JLabel("연체료");
		JButton button_close = new JButton("닫기");
		button_close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button_close.setSize(20, 50);
		JPanel label_panel = new JPanel();
		TextArea loanListArea = new TextArea(10, 50);
		label_panel.setLayout(null);
		name_label.setBounds(500,150,20,10);
		label_panel.add(name_label);
		label_panel.add(pNum_label);
		label_panel.add(due_label);
		label_panel.add(fee_label);

		loanListArea.setText("현재 대여목록이 없습니다.");
		JPanel loanListPanel = new JPanel();
		JScrollPane scrollPane = new JScrollPane(loanListArea);

		loanListPanel.add(scrollPane, "North");
		loanListPanel.add(button_close);
		loanListPanel.setLocation(500,300);
		this.add(label_panel);
		this.add(loanListPanel);
		this.setVisible(true);
		this.pack();
		this.setResizable(false);
		String str = lm.overdueBook();
		ArrayList<Member> delayList = lm.getDelayList();
		if (delayList.isEmpty()) {
			loanListArea.setText("현재 연체 목록이 없습니다.");
		} else {
			loanListArea.setText(str);
		}
	}

}
