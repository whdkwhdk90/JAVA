package com.test01;


public class Main {

		public static void main(String[] args) {
		DeArrayTest init  = new DeArrayTest();
//		init.testInit();
//		init.testInit2();
//		init.testInit3();
		init.testInit4();
		
		DeArrayTest02 init1  = new DeArrayTest02();
		init1.test01();
		
}
}