(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("form_Test");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Static("Static00","63","30","475","160",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("Number 3자리마다 콤마");
            this.addChild(obj.name, obj);

            obj = new MaskEdit("MaskEdit01","210","84","320","56",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_format("#,###");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","55","197","482","122",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("String 000-000-000");
            this.addChild(obj.name, obj);

            obj = new MaskEdit("MaskEdit00","175","231","345","49",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_format("999-999");
            obj.set_type("string");
            this.addChild(obj.name, obj);

            obj = new CheckBox("CheckBox00","637","79","100","59",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("CheckBox00");
            this.addChild(obj.name, obj);

            obj = new ListBox("ListBox00","633","159","189","69",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            this.addChild(obj.name, obj);

            obj = new Radio("Radio00","632","264","254","116",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Radio00_innerdataset = new nexacro.NormalDataset("Radio00_innerdataset", obj);
            Radio00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">컴퓨터</Col><Col id=\"datacolumn\">컴퓨터</Col></Row><Row><Col id=\"codecolumn\">노트북</Col><Col id=\"datacolumn\">노트북</Col></Row><Row><Col id=\"codecolumn\">태블릿</Col><Col id=\"datacolumn\">태블릿</Col></Row></Rows>");
            obj.set_innerdataset(Radio00_innerdataset);
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","69","330","301","106",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"datacolumn\">컴퓨터</Col><Col id=\"codecolumn\">com</Col></Row><Row><Col id=\"datacolumn\">노트북</Col><Col id=\"codecolumn\">lap</Col></Row><Row><Col id=\"codecolumn\">tab</Col><Col id=\"datacolumn\">태블릿</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("Combo00");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1280,720,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("form_Test.xfdl", function() {
        var innerDS = this.Radio00.getInnerDataset();
        innerDS.insertRow(1);
        innerDS.setColumn(1,"codecolumn","code값");
        innerDS.setColumn(1,"datacolumn","data값");
        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Static00.addEventHandler("onclick",this.Static00_onclick,this);
            this.MaskEdit01.addEventHandler("onchanged",this.MaskEdit01_onchanged,this);
            this.Static01.addEventHandler("onclick",this.Static01_onclick,this);
            this.MaskEdit00.addEventHandler("onchanged",this.MaskEdit00_onchanged,this);
            this.CheckBox00.addEventHandler("onclick",this.CheckBox00_onclick,this);
        };

        this.loadIncludeScript("form_Test.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
