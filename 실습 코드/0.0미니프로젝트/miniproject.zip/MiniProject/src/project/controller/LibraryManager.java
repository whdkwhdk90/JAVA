package project.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import project.Model.Book;
import project.Model.Member;

public class LibraryManager {

	private ArrayList<Book> bookList = new ArrayList<>();
	private ArrayList<Book> delayList = new ArrayList<>();
	private HashMap<Integer,Member> Mmap = new HashMap<>();
	private int[] keyArr = new int[1000];
	private int Key = 0; // map의 맨처음 key의 값
	private int Val = 0; // list의 맨처음 값
	private int fee; //내야되는 요금
	private int[] countArr = new int[1000]; //빌릴 때 마다 늘어가는 count
	
	//key자체를 배열화 시켜서 배열로 관리. keAarr에는 해당되는 key의 값들이 들어감.
	//예를들어 대여에서 누군가 그 책을 빌렸다면 그 누군가에 대한 map에서의 key값을 key[0], key[1]에 넣는다면 
	//그 사람에 대해 빌린 것을 출력할 수 있다.
	
	//count도 배열로 만들어서 대여 시에 count를 늘려 countArr[bookList의 key]에 저장하면 
	//그 중에 값이 가장 높은 값을 가지는 bookList의 key를 가져와서 출력할 수 있다. 
	
	//요금에 대해서는 대여 시에 현재시간을 넣어주고 반납 시에 현재시간과의 차이를 계산하여
	//(4.24에 톡방에 시간차이 계산하는 블로그 올렸음) 10초당 100원씩 계산할 수 있도록함.
	
	//연체는 기본 30초(10초당 100원씩 추가시)로 하며 30초가 넘는 것에 대해서 연체list에 추가.
	
	
	
	public LibraryManager() {
		
	}
	
	public void addBook(String author, String title, int price) {
		//3개 입력받은 것을 그대로 list에 추가
	}
	
	public void changeBook(int num) {
		//num이 1이냐 2이냐에 따라 각각 구현
	}
	
	public void loanBook(int num) {
		//num이 1이냐 2이냐에 따라 각각 구현
	}
	
	public void search(int num) {
		//num이 1이냐 2이냐에 따라 각각 구현
	}
	
	public void weekBook() {
		//
	}
	
	public void overdueBook() {}
	
	
	
	public void bookList() {	
		for(int i=0; i<bookList.size(); i++) {
			System.out.println(bookList.get(i));
		}	
	}
	
	public void memberList() {
		Set Mset  = Mmap.entrySet();
		Iterator MsetIt = Mset.iterator();
		
		while(MsetIt.hasNext()) {
			System.out.println(MsetIt.next());
		}
		
	}
	
	
	
	
}
