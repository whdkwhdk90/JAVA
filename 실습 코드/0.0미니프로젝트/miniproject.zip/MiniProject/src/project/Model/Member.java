package project.Model;

public class Member {

	private String name;
	private int pnum;
	
	public Member(String name, int pnum) {
		
		this.name = name;
		this.pnum = pnum;
	}

	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPnum() {
		return pnum;
	}

	public void setPnum(int pnum) {
		this.pnum = pnum;
	}



	@Override
	public String toString() {
		return " [이름 = " + name + ", 전화번호 = " + pnum + "]";
	}
	
	
	
	
	
	
}
