package project.run;

import project.view.LibraryMenu;

public class LibraryMain {

	public static void main(String[] args) {

		LibraryMenu menu = new LibraryMenu();
		menu.mainMenu();
		
		
		
	}

}
