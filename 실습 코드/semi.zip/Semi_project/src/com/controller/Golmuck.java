package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/golmuck.do")
public class Golmuck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Golmuck() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String cd = request.getParameter("cd");
		
		if(cd.equals("agender")) {
			response.sendRedirect("ageGender.do?cd=agender");
		}else if(cd.equals("cook")) {
			response.sendRedirect("cook.do?cd=cook");
		}else if(cd.equals("total")) {
			response.sendRedirect("total.do?cd=total");
		}else if(cd.equals("nation")) {
			response.sendRedirect("nation.do?cd=nation");
		}else if(cd.equals("mapSms")) {
			response.sendRedirect("mapsms.do?cd=mapsms");
		}else if(cd.equals("main")) {
			response.sendRedirect("main.jsp");
		}else if(cd.equals("issue")) {
			response.sendRedirect("issue.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
