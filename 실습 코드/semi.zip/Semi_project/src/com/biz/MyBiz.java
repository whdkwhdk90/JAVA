package com.biz;

import com.dao.foodDao;
import com.dao.memberDao;
import com.dao.popularityDao;
import com.dto.memberDto;

public class MyBiz {

	private memberDao ddao = new memberDao();
	private popularityDao pdao = new popularityDao();
	private foodDao fdao = new foodDao();
	
//-----------------------------------------------------------------------------
	
//--------------------------member-----------------------------------------------
	
	public int insert(memberDto member) {
		return ddao.insert(member);
	}
	public memberDto selectOne(int mno) {
		return ddao.selectOne(mno);
	}
	
//------------------------------------------------------------------------------
	
	
	
//-------------------------------popularity----------------------------------------	
	
	
	
	
//------------------------------------------------------------------------------	
	

	
//------------------------------food-----------------------------------------------	
	
	
//------------------------------------------------------------------------------	
		
	
	
	
	
}
