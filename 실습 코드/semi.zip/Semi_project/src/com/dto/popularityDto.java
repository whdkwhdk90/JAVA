package com.dto;

public class popularityDto {
	private int fno;
	private int mno;
	private int mage;
	private String mgender;
	
	public popularityDto() {
		super();
	}

	public popularityDto(int fno, int mno, int mage, String mgender) {
		this.fno = fno;
		this.mno = mno;
		this.mage = mage;
		this.mgender = mgender;
	}

	public int getFno() {
		return fno;
	}

	public void setFno(int fno) {
		this.fno = fno;
	}

	public int getMno() {
		return mno;
	}

	public void setMno(int mno) {
		this.mno = mno;
	}

	public int getMage() {
		return mage;
	}

	public void setMage(int mage) {
		this.mage = mage;
	}

	public String getMgender() {
		return mgender;
	}

	public void setMgender(String mgender) {
		this.mgender = mgender;
	}
	
	
	
	
}
