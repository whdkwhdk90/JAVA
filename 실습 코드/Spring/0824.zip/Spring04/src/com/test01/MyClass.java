package com.test01;

public class MyClass {
	
	//기본 생성자
	public MyClass() {
		System.out.println("MyClass constructor call!");
	}
	
	//메소드
	public void prn() {
		System.out.println("prn() 메서드 호출!");
	}
	
}
