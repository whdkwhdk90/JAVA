package com.test07;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MTest {

	public static void main(String[] args) {

		ApplicationContext factory = new ClassPathXmlApplicationContext("com/test07/applicationContext.xml");
		
		System.out.println("spring Bean Container 생성");
		
		//원래 설정이라면 bean이 먼저 생성되고(bean 자체가 먼저 생성되고) 그다음 내용이 진행되는데 
		// lg tv 생성, samsung tv 생성 후 위에 출력문부터 시작
		//근데 bean에서 lazy-init을 true로 해놓으면 여기서 순차적으로 진행될 때 생성이 된다.
		
		LgTV lg = factory.getBean("lg",LgTV.class);
		lg.powerOn();
		lg.volUp();
		lg.volDown();
		lg.powerOff();
		SamsungTV samsung = factory.getBean("samsung",SamsungTV.class);
		samsung.powerOn();
		samsung.volUp();
		samsung.volDown();
		samsung.powerOff();
		
		
		
	}

}
