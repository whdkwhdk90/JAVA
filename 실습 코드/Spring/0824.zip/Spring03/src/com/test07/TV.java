package com.test07;

public interface TV {
	void powerOn();
	void powerOff();
	void volUp();
	void volDown();
}
