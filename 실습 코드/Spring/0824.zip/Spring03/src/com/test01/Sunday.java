package com.test01;

public class Sunday extends AbstractTest{

	@Override
	public String dayInfo() {
		return "일요일";
	}

}
