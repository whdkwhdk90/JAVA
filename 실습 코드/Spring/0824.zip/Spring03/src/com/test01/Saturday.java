package com.test01;

public class Saturday extends AbstractTest{

	@Override
	public String dayInfo() {
		return "토요일";
	}

}
