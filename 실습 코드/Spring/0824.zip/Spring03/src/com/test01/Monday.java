package com.test01;

public class Monday extends AbstractTest{

	@Override
	public String dayInfo() {
		return "월요일";
	}

}
