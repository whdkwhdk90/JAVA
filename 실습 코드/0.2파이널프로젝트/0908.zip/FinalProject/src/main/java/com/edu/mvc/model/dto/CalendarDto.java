package com.edu.mvc.model.dto;

import java.util.Date;

public class CalendarDto {
	private String memeberid;
	private String title;
	private String detail;
	private Date sdate;
	private Date fdate;
	private int individual;
	
	public CalendarDto() {
		super();
	}

	public CalendarDto(String memeberid, String title, String detail, Date sdate, Date fdate, int individual) {
		super();
		this.memeberid = memeberid;
		this.title = title;
		this.detail = detail;
		this.sdate = sdate;
		this.fdate = fdate;
		this.individual = individual;
	}

	public String getMemeberid() {
		return memeberid;
	}

	public void setMemeberid(String memeberid) {
		this.memeberid = memeberid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public Date getSdate() {
		return sdate;
	}

	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}

	public Date getFdate() {
		return fdate;
	}

	public void setFdate(Date fdate) {
		this.fdate = fdate;
	}

	public int getIndividual() {
		return individual;
	}

	public void setIndividual(int individual) {
		this.individual = individual;
	}

	@Override
	public String toString() {
		return "CalendarDto [memeberid=" + memeberid + ", title=" + title + ", detail=" + detail + ", sdate=" + sdate
				+ ", fdate=" + fdate + ", individual=" + individual + "]";
	}
	
	
	
}
