package com.edu.mvc.model.biz;

public class TimerBiz {

}
