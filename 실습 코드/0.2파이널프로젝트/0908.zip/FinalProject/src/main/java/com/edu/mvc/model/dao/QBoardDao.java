package com.edu.mvc.model.dao;

public class QBoardDao {

}
