package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.stereotype.Service;

import com.edu.mvc.model.dto.MemberDto;

@Service
public class MemberBiz {

public List<MemberDto> selectList(){
		
		return null;
	}
	
	public MemberDto selectOne(String memberid) {
		
		return null;
	}
	
	public int insert(MemberDto dto) {
		
		return 0;
	}
	
	public int update(MemberDto dto) {
		
		return 0;
	}
	
	public int delete(String memberid) {
		
		return 0;
	}
	
}
