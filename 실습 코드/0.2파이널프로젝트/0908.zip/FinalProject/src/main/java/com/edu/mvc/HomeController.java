package com.edu.mvc;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}
	
	@RequestMapping("/icons.do")
	public String icons() {
		logger.info("[log] : icons.jsp");
		return "icons";
	}
	
	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}
	
	@RequestMapping("/map.do")
	public String map() {
		logger.info("[log] : map.jsp");
		return "map";
	}
	
	@RequestMapping("/maps.do")
	public String maps() {
		logger.info("[log] : maps.jsp");
		return "maps";
	}
	
	@RequestMapping("/profile.do")
	public String profile() {
		logger.info("[log] : profile.jsp");
		return "profile";
	}
	
	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}
	
	@RequestMapping("/tables.do")
	public String tables() {
		logger.info("[log] : tables.jsp");
		return "tables";
	}
	
	@RequestMapping("/upgrade.do")
	public String upgrade() {
		logger.info("[log] : upgrade.jsp");
		return "upgrade";
	}
	
}
