package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.stereotype.Service;

import com.edu.mvc.model.dto.QAnswerDto;

@Service
public class QAnswerBiz {

public List<QAnswerDto> selectList(){
		
		return null;
	}
	
	public QAnswerDto selectOne() {
		
		return null;
	}
	
	public int insert(QAnswerDto dto) {
		
		return 0;
	}
	
	public int update(QAnswerDto dto) {
		
		return 0;
	}
	
	public int delete(String memberid) {
		
		return 0;
	}
	
}
