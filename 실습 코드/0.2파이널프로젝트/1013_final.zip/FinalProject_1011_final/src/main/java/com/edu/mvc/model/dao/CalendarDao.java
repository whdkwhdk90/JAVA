package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.CalendarDto;

@Repository
public class CalendarDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "Calendar.";

	public List<CalendarDto> selectList() {

		return null;
	}

	public CalendarDto selectOne(String memberid) {

		return null;
	}

	public int insert(CalendarDto dto) {

		return 0;
	}

	public int update(CalendarDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}

}
