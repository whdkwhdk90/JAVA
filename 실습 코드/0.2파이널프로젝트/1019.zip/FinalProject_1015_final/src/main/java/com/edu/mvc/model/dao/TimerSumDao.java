package com.edu.mvc.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.TimerSumDto;

@Repository
public class TimerSumDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "timer.";

	// 전체
	public List<TimerSumDto> selectAll(String memberid) {
		List<TimerSumDto> list = new ArrayList<TimerSumDto>();

		try {
			list = sqlSession.selectList(NAMESPACE + "selectSumAll", memberid);
			System.out.println("여기까지도 됐다..!! ㅠ");
		} catch (Exception e) {
			System.out.println("[error] : select Time error");
			e.printStackTrace();
		}
		return list;
	}

	// 이번주
	public List<TimerSumDto> selectThisWeek(String memberid) {
		List<TimerSumDto> listTW = new ArrayList<TimerSumDto>();

		try {
			listTW = sqlSession.selectList(NAMESPACE + "selectThisWeek", memberid);
		} catch (Exception e) {
			System.out.println("[error] : 이번주 데이터 불러오기 실패 ");
			e.printStackTrace();
		}

		return listTW;
	}

	// 일주일
	public TimerSumDto selectMon(String memberid) {
		TimerSumDto mon = null;

		try {
			mon = sqlSession.selectOne(NAMESPACE + "selectMon", memberid);
		} catch (Exception e) {
			System.out.println("[error]: mon data 조회 실패 ");
			e.printStackTrace();
		}
		return mon;
	}

	public TimerSumDto selectTue(String memberid) {
		TimerSumDto tue = null;

		try {
			tue = sqlSession.selectOne(NAMESPACE + "selectTue", memberid);
		} catch (Exception e) {
			System.out.println("[error]: tue data 조회 실패 ");
			e.printStackTrace();
		}
		return tue;
	}

	public TimerSumDto selectWed(String memberid) {
		TimerSumDto wed = null;

		try {
			wed = sqlSession.selectOne(NAMESPACE + "selectWed", memberid);
		} catch (Exception e) {
			System.out.println("[error]: wed data 조회 실패 ");
			e.printStackTrace();
		}
		return wed;
	}

	public TimerSumDto selectThu(String memberid) {
		TimerSumDto thu = null;

		try {
			thu = sqlSession.selectOne(NAMESPACE + "selectThu", memberid);
		} catch (Exception e) {
			System.out.println("[error]: thu data 조회 실패 ");
			e.printStackTrace();
		}
		return thu;
	}

	public TimerSumDto selectFri(String memberid) {
		TimerSumDto fri = null;

		try {
			fri = sqlSession.selectOne(NAMESPACE + "selectFri", memberid);
		} catch (Exception e) {
			System.out.println("[error]: fri data 조회 실패 ");
			e.printStackTrace();
		}
		return fri;
	}

	public TimerSumDto selectSat(String memberid) {
		TimerSumDto sat = null;

		try {
			sat = sqlSession.selectOne(NAMESPACE + "selectSat", memberid);
		} catch (Exception e) {
			System.out.println("[error]: sat data 조회 실패 ");
			e.printStackTrace();
		}
		return sat;
	}

	public TimerSumDto selectSun(String memberid) {
		TimerSumDto sun = null;

		try {
			sun = sqlSession.selectOne(NAMESPACE + "selectSun", memberid);
		} catch (Exception e) {
			System.out.println("[error]: sun data 조회 실패 ");
			e.printStackTrace();
		}
		return sun;
	}

	public TimerSumDto selectOne(String memberid) {
		TimerSumDto dto = null;

		try {
			dto = sqlSession.selectOne(NAMESPACE + "selectSumToday", memberid);
		} catch (Exception e) {
			System.out.println("[error] : select One error");
			e.printStackTrace();
		}
		return dto;
	}

	public int insert(TimerSumDto sumDto) {
		int res = 0;
		try {
			res = sqlSession.insert(NAMESPACE + "insertSum", sumDto);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return res;
	}

}
