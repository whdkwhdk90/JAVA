package com.edu.mvc.common.filter;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class chkFilter implements Filter{

	//로거객체
	private Logger logger = LoggerFactory.getLogger(chkFilter.class);
		
	/* init() : 필터 초기화
	 * doFilter() : 전/후 처리
	 * destroy() : 필터 인스턴스 종료
	 * */
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		logger.info("[LOG : chkFilter]");
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		String url = req.getRequestURL().toString();
		System.out.println(url);
		
		
		System.out.println(req.getSession(false) == null);
		System.out.println("filter는 한국말 ㄴㄴ?");
		
		if(!(url.contains("start.jsp") || url.contains("login.do") || url.contains("/register.do") ||
				url.contains("/logind.do") || url.contains("/ajaxLogin.do") || url.contains("/ajaxRegister.do") ||
				url.contains("/regchk.do") ||  url.contains("/logout.do")   )) {
			
			
			chain.doFilter(req, resp);
		}	
		
		//계속 마저 하겠다.
		chain.doFilter(req, resp);
	}

	@Override
	public void destroy() {
		
	}

}
