package com.edu.mvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.QBoardBiz;
import com.edu.mvc.model.dto.QBoardDto;

@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}

	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}

	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}

	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "youtube";
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// QBoard //
	@Autowired
	private QBoardBiz QBBiz;

	@RequestMapping("/qna.do")
	public String qna(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : qna.jsp");
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;
		
		
		
		
		
		
		
		
		
		
		
		for(int i=mynumber; i<mynumber+5;i++) {
			dtoss.add(dtos.get(i));
		}
		
		System.out.println("myno : " + myno);
		System.out.println(dtoss.toString());
		System.out.println("res : " + res);
		
		model.addAttribute("dtoss", dtoss);
		model.addAttribute("myno", myno);
		model.addAttribute("res", res);
		
		return "qna";
	}

	@ResponseBody
	@RequestMapping("/ajaxQBoard.do")
	public Map<String,Object> ajaxQBoard(HttpServletRequest httpServletRequest) {
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		Map<String,Object> rmap  = new HashMap<>();
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;
		
		for(int i=mynumber; i<mynumber+5;i++) {
			dtoss.add(dtos.get(i));
		}
		
		rmap.put("myno", myno);
		rmap.put("dtoss", dtoss);
		rmap.put("res", res);
		
		return rmap;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@RequestMapping("/mypage.do")
	public String mypage() {
		logger.info("[log] : mypage.jsp");
		return "mypage";
	}

	@RequestMapping("/study.do")
	public String study() {
		logger.info("[log] : study.jsp");
		return "study";
	}

}
