package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dto.RecruitAnswerDto;

public class RecruitAnswerDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "recruitanswer.";

	public List<RecruitAnswerDto> selectList() {

		return null;
	}

	public RecruitAnswerDto selectOne(String memberid) {

		return null;
	}

	public int insert(RecruitAnswerDto dto) {

		return 0;
	}

	public int update(RecruitAnswerDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
}
