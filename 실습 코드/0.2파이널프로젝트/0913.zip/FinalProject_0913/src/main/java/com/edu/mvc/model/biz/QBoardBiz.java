package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.QBoardDao;
import com.edu.mvc.model.dto.QBoardDto;

@Service
public class QBoardBiz {

	@Autowired
	private QBoardDao dao;
	
	public List<QBoardDto> selectList(String myno) {
		return dao.selectList(myno);
	}

	public QBoardDto selectOne() {

		return null;
	}

	public int insert(QBoardDto dto) {

		return 0;
	}

	public int update(QBoardDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
}
