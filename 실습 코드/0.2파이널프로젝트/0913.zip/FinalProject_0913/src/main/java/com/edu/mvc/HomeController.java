package com.edu.mvc;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.QBoardBiz;
import com.edu.mvc.model.dto.QBoardDto;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	
	
	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}
	
	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}
		
	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}
			
	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "youtube";
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// QBoard //
	@Autowired
	private QBoardBiz QBBiz;
	
	@RequestMapping("/qna.do")
	public String qna(HttpServletRequest httpServletRequest,Model model) {
		logger.info("[log] : qna.jsp");
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList(myno);
		model.addAttribute("dtos", dtos);
		model.addAttribute("myno", myno);
		return "qna";
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	@RequestMapping("/mypage.do")
	public String mypage() {
		logger.info("[log] : mypage.jsp");
		return "mypage";
	}
	
	@RequestMapping("/study.do")
	public String study() {
		logger.info("[log] : study.jsp");
		return "study";
	}
	
}
