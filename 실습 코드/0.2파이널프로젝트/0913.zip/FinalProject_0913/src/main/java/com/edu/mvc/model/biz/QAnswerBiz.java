package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.QAnswerDao;
import com.edu.mvc.model.dto.QAnswerDto;

@Service
public class QAnswerBiz {

	@Autowired
	private QAnswerDao dao;
	
	public List<QAnswerDto> selectList() {

		return null;
	}

	public QAnswerDto selectOne() {

		return null;
	}

	public int insert(QAnswerDto dto) {

		return 0;
	}

	public int update(QAnswerDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}

}
