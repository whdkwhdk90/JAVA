package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.QBoardDto;

@Repository
public class QBoardDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "qboard.";

	public List<QBoardDto> selectList() {
		List<QBoardDto> dtos = null;
		dtos = sqlSession.selectList(NAMESPACE+"selectList");
		return dtos;
	}

	public QBoardDto selectOne(int myno) {
		QBoardDto dto = null;
		dto = sqlSession.selectOne(NAMESPACE+"selectOne",myno);
		return dto;
	}

	public int insert(QBoardDto dto) {

		return 0;
	}

	public int update(QBoardDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}


	
}
