package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dto.TimerDto;

public class TimerDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "timer.";

	public List<TimerDto> selectList() {

		return null;
	}

	public TimerDto selectOne(String memberid) {

		return null;
	}

	public int insert(TimerDto dto) {

		return 0;
	}

	public int update(TimerDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
}
