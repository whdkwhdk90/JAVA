package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.RecruitBoardDao;
import com.edu.mvc.model.dto.RecruitBoardDto;


@Service
public class RecruitBoardBiz {

	@Autowired
	private RecruitBoardDao dao;
	
	public List<RecruitBoardDto> selectList() {
		return dao.selectList();
	}

	public RecruitBoardDto selectOne(int rbseq) {
		dao.count(rbseq);
		return dao.selectOne(rbseq);
	}

	public int insert(RecruitBoardDto rbdto) {
		return dao.insert(rbdto);
	}

	public int update(RecruitBoardDto rbdto) {

		return dao.update(rbdto);
	}

	public int delete(int rbseq) {

		return dao.delete(rbseq);
	}
	
	
}
