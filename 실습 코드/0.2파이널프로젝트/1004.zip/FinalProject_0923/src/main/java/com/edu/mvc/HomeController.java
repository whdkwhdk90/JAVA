package com.edu.mvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.QBoardBiz;
import com.edu.mvc.model.biz.RecruitAnswerBiz;
import com.edu.mvc.model.biz.RecruitBoardBiz;
import com.edu.mvc.model.dto.MemberDto;
import com.edu.mvc.model.dto.QBoardDto;
import com.edu.mvc.model.dto.RecruitAnswerDto;
import com.edu.mvc.model.dto.RecruitBoardDto;

@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Resource
	private HttpSession session;
	
	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// QBoard //
	@Autowired
	private QBoardBiz QBBiz;

	@RequestMapping("/qna.do")
	public String qna(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : qna.jsp");
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;
		
		if (res < 5) {
			for (int i = 0; i < res; i++) {
					dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
					dtoss.add(dtos.get(i));
			}
		}

		System.out.println("myno : " + myno);
		System.out.println(dtoss.toString());
		System.out.println("res : " + res);

		model.addAttribute("dtoss", dtoss);
		model.addAttribute("myno", myno);
		model.addAttribute("res", res);

		return "qna";
	}

	@ResponseBody
	@RequestMapping("/ajaxQBoard.do")
	public Map<String, Object> ajaxQBoard(HttpServletRequest httpServletRequest) {
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		Map<String, Object> rmap = new HashMap<>();
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;

		if (res - mynumber < 5) {
			for (int i = mynumber; i < res; i++) {
				dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
				dtoss.add(dtos.get(i));
			}
		}

		rmap.put("myno", myno);
		rmap.put("dtoss", dtoss);
		rmap.put("res", res);

		return rmap;
	}

	@RequestMapping("/qnaWrite.do")
	public String qnaWrite(HttpServletRequest httpServletRequest, Model model) {
		session = httpServletRequest.getSession();
		logger.info("[log] : qnaWrite.jsp");
		System.out.println("찍히나?");
		if(session.getAttribute("logindto") == null) {
			return "redirect:login.do";
		}else {
			MemberDto mdto = (MemberDto)httpServletRequest.getAttribute("login");
			model.addAttribute("mdto",mdto);
			return "qnaWrite";
		}
	}
	
	@RequestMapping("/qnaDetail.do")
	public String qnadetail(HttpServletRequest httpServletRequest, Model model) {
		session = httpServletRequest.getSession();
		int myno = Integer.parseInt(httpServletRequest.getParameter("myno").trim());
		int pagelength = Integer.parseInt(httpServletRequest.getParameter("pagelength").trim());
		logger.info("[log] : qnaDetail.jsp");
		QBoardDto mdto = QBBiz.selectOne(myno);
		if(session.getAttribute("logindto") == null) {
			System.out.println(session.getAttribute("logindto") == null);
			return "redirect:login.do";
		}else {
			//현재 session에 담겨있는 로그인 정보들을 객체로 남아서 qnaDetail페이지로 넘겨줌.
			model.addAttribute("pagelength",pagelength);
			model.addAttribute("mdto",mdto);
			return "qnaDetail";
		}
	}
		
	@RequestMapping("/qnaList.do")
	public String qnaList(HttpServletRequest httpServletRequest, Model model) {
		
		return null;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//유튜브 게시판

	
	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "testyoutube";
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//구인 게시판
	
	@Autowired
	private RecruitBoardBiz rbbiz;
	
	@Autowired
	private RecruitAnswerBiz rabiz;
	
	@RequestMapping("/mypage.do")
	public String mypage() {
		logger.info("[log] : mypage.jsp");
		return "mypage";
	}

	@RequestMapping("/study.do")
	public String study(Model model) {
		logger.info("[log] : study.jsp");
		model.addAttribute("study", rbbiz.selectList());
		
		return "study";
	}

	@RequestMapping("/studyinsertform.do")
	public String studyInsertForm() {
		logger.info("[log] : studyinsertform");
		return "studyinsert";
	}

	@RequestMapping("/studyinsertres.do")
	public String studyInsertRes(RecruitBoardDto rbdto) {
		logger.info("[log] : studyinsertres");
		int res = rbbiz.insert(rbdto);
		if (res > 0) {
			return "redirect:study.do";
		} else {
			return "redirect:studyinsertform.do";
		}
	}
	
	
	@RequestMapping("/studyupdateform.do")
	public String studyUpdateForm(Model model, int rbseq) {
		logger.info("[log] : study update form");
		
		model.addAttribute("rbdto", rbbiz.selectOne(rbseq));
		
		return "studyupdate";
	}

	
	@RequestMapping("/studyupdateres.do")
	public String studyUpdateRes(RecruitBoardDto rbdto) {
		logger.info("[log] : study update res");
		int res = rbbiz.update(rbdto);
		if(res > 0) {
			return "redirect:studydetail.do?rbseq="+rbdto.getRbseq();
		}else {
			return "redirect:studyupdateform.do?rbseq="+rbdto.getRbseq();
		}
		
	}

	
	
	@RequestMapping("delete.do")
	public String delete(int rbseq) {
		logger.info("[log] : study delete");
		int res = rbbiz.delete(rbseq);
		
		if(res>0) {
			return "redirect:study.do";
		}else {
			return "redirect:studydetail.do?rbseq="+rbseq;
		}
	}

	
	
	
	@RequestMapping("/studydetail.do")
	public String studyDetail(Model model, int rbseq) {
		logger.info("[log] : study detail");
		model.addAttribute("rbdto", rbbiz.selectOne(rbseq));
		model.addAttribute("radto", rabiz.selectList(rbseq));
		
		return "studydetail";
	}
	
	
	@RequestMapping("/studyanswerinsert.do")
	public String studyAnswerInsert(RecruitAnswerDto radto) {
		int res = rabiz.insert(radto);
		if(res>0) {
			return "redirect:studydetail.do?rbseq="+radto.getRbseq();
		}else {
			return "redirect:studydetail.do?rbseq="+radto.getRbseq();
		}
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	
	
	
	
}
