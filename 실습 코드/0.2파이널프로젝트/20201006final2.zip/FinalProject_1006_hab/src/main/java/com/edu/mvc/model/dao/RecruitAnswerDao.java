package com.edu.mvc.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.RecruitAnswerDto;

@Repository
public class RecruitAnswerDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "recruitanswer.";

	public List<RecruitAnswerDto> selectList(int rbseq) {
		List<RecruitAnswerDto> list = new ArrayList<RecruitAnswerDto>();
		
		try {
			list = sqlSession.selectList(NAMESPACE+"selectList", rbseq);
		} catch (Exception e) {
			System.out.println("[error] : answer selectList");
			e.printStackTrace();
		}
		
		return list;
	}

	
	public int insert(RecruitAnswerDto radto) {
		int res = 0;
		
		try {
			res = sqlSession.insert(NAMESPACE+"insert", radto);
		} catch (Exception e) {
			System.out.println("[error] : answer insert");
			e.printStackTrace();
		}
		return res;
	}

	public int update(RecruitAnswerDto dto) {
		
		
		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
}
