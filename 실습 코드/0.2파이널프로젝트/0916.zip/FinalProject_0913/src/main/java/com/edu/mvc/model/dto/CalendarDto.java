package com.edu.mvc.model.dto;

import java.util.Date;

public class CalendarDto {
	private String memberid;
	private String title;
	private String detail;
	private Date sdate;
	private Date fdate;
	private int ind;
	private String color;
	private int seq;
	public CalendarDto() {
		super();
	}
	
	public CalendarDto(String memberid, String title, String detail, Date sdate, Date fdate, int ind, String color,
			int seq) {
		super();
		this.memberid = memberid;
		this.title = title;
		this.detail = detail;
		this.sdate = sdate;
		this.fdate = fdate;
		this.ind = ind;
		this.color = color;
		this.seq = seq;
	}
	
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getdetail() {
		return detail;
	}
	public void setdetail(String detail) {
		this.detail = detail;
	}
	public Date getSdate() {
		return sdate;
	}
	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}
	public Date getFdate() {
		return fdate;
	}
	public void setFdate(Date fdate) {
		this.fdate = fdate;
	}
	public int getInd() {
		return ind;
	}
	public void setInd(int ind) {
		this.ind = ind;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	
	@Override
	public String toString() {
		return "CalendarDto [memberid=" + memberid + ", title=" + title + ", detail=" + detail + ", sdate=" + sdate
				+ ", fdate=" + fdate + ", ind=" + ind + ", color=" + color + ", seq=" + seq + "]";
	}
	
	
	
}
