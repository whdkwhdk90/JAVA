package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.MemberDto;

@Repository
public class MemberDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	private String NAMESPACE = "member.";
	
	public List<MemberDto> loginchk(MemberDto ldto) {
			return null;
	}

	public MemberDto selectOne(MemberDto ldto) {
		MemberDto mdto = new MemberDto();
		mdto = sqlSession.selectOne(NAMESPACE+"selectOne",ldto);
		return mdto;
	}

	public int insert(MemberDto dto) {
		int res = 0;
		res = sqlSession.insert(NAMESPACE+"insert",dto);
		return res;
	}

	public int update(MemberDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}

	public MemberDto selectOne(String memberid) {
		MemberDto mdto = new MemberDto();
		mdto = sqlSession.selectOne(NAMESPACE+"selectOneRei",memberid);
		return mdto;
	}
	
	
}
