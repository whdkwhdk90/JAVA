package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dao.RecruitBoardDao;
import com.edu.mvc.model.dto.RecruitBoardDto;

public class RecruitBoardBiz {

	@Autowired
	private RecruitBoardDao dao;
	
	public List<RecruitBoardDto> selectList() {

		return null;
	}

	public RecruitBoardDto selectOne() {

		return null;
	}

	public int insert(RecruitBoardDto dto) {

		return 0;
	}

	public int update(RecruitBoardDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
	
}
