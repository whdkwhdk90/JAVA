package com.edu.mvc.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.TimerSumDto;

@Repository
public class TimerSumDao {
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	private String NAMESPACE = "timer.";
	

	//전체 
	public List<TimerSumDto> selectAll(String memberid) {
		List<TimerSumDto> list = new ArrayList<TimerSumDto>();
		
		try {
			list = sqlSession.selectList(NAMESPACE+"selectSumAll", memberid);
			System.out.println("여기까지도 됐다..!! ㅠ");
		} catch (Exception e) {
			System.out.println("[error] : select Time error");
			e.printStackTrace();
		}
		return list;
	}
	
	//이번주
	public List<TimerSumDto> selectThisWeek(String memberid) {
		List<TimerSumDto> listTW = new ArrayList<TimerSumDto>();
		
		try {
			listTW = sqlSession.selectList(NAMESPACE+"selectThisWeek", memberid);
		} catch (Exception e) {
			System.out.println("[error] : 이번주 데이터 불러오기 실패 ");
			e.printStackTrace();
		}
		
		return listTW;
	}
	

	
	//한달 (9월)
	public List<TimerSumDto> selectMonth(String memberid) {
		List<TimerSumDto> list = new ArrayList<TimerSumDto>();
		
		try {
			list = sqlSession.selectList(NAMESPACE + "selectSep", memberid);
		} catch (Exception e) {
			System.out.println("[error] : 9월달 불러오기 실패 ");
			e.printStackTrace();
		}
		
		return list;
	}
	
	public TimerSumDto selectOne(String memberid) {
		TimerSumDto dto = null;
		
		try {
			dto = sqlSession.selectOne(NAMESPACE+"selectSumToday", memberid);
		} catch (Exception e) {
			System.out.println("[error] : select One error");
			e.printStackTrace();
		}
		return dto;
	}
	
	public int insert(TimerSumDto sumDto) {
		int res = 0;
		try {
			res = sqlSession.insert(NAMESPACE+"insertSum", sumDto);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return res;
	}


}
