package com.edu.mvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.MemberBiz;
import com.edu.mvc.model.biz.QBoardBiz;
import com.edu.mvc.model.dto.MemberDto;
import com.edu.mvc.model.dto.QBoardDto;

@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// LOGIN/REGISTER //
	@Autowired
	private MemberBiz lbiz;
	
	@RequestMapping("/loginindex.do")
	public String loginIndex(HttpServletRequest httpServletRequest) {
		String memberid = (String)httpServletRequest.getParameter("memberid").trim();
		String memberpw = (String)httpServletRequest.getParameter("memberpw").trim();
		String name = (String)httpServletRequest.getParameter("name").trim();
		String email = (String)httpServletRequest.getParameter("email").trim();
		
		MemberDto logindto = new MemberDto();
		logindto.setMemberid(memberid);
		logindto.setMemberpw(memberpw);
		logindto.setName(name);
		logindto.setEmail(email);
		
		httpServletRequest.getSession().setAttribute("logindto", logindto);
		System.out.println(logindto);
		return "index";
	}
	
	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpServletRequest httpServletRequest) {
		httpServletRequest.getSession().invalidate();
		httpServletRequest.getSession(false);
		return "index";
	}
	
	@ResponseBody
	@RequestMapping("/ajaxLogin.do")
	public Map<String, Object> loginchk(HttpServletRequest httpServletRequest, @RequestParam(value="memberid")String memberid,
			@RequestParam(value="memberpw")String memberpw) {
		System.out.println(memberid);
		System.out.println(memberpw);
		logger.info("[log] : ajaxLogin");
		MemberDto ldto = new MemberDto();
		ldto.setMemberid(memberid.trim());
		ldto.setMemberpw(memberpw.trim());
		Map<String,Object> mmap = new HashMap<>();
		MemberDto mdto = lbiz.selectOne(ldto);
		boolean valid = false;
		if(mdto != null) {
			mmap.put("mdto", mdto);
			valid = true;
		}
		mmap.put("valid", valid);
			return mmap;
		
	}

	@ResponseBody
	@RequestMapping("/ajaxRegister.do")
	public Map<String, Object> registerchk(HttpServletRequest httpServletRequest,@RequestParam(value="memberid")String memberid) {
		logger.info("[log] : ajaxRegister");
		Map<String,Object> mmap = new HashMap<>();
		MemberDto mdto = lbiz.selectOne(memberid);
		boolean valid = false;
		if(mdto != null) {
			mmap.put("mdto", mdto);
			valid = true;
		}
		mmap.put("valid", valid);
			return mmap;
		
	}
	
	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}

	@RequestMapping("/regchk.do")
	public String regchk(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : regchk");
		String memberid = (String)httpServletRequest.getParameter("memberid").trim();
		String memberpw = (String)httpServletRequest.getParameter("memberpw").trim();
		String name = (String)httpServletRequest.getParameter("name").trim();
		String email = (String)httpServletRequest.getParameter("email").trim();
		
		MemberDto dto = new MemberDto();
		dto.setMemberid(memberid);
		dto.setMemberpw(memberpw);
		dto.setName(name);
		dto.setEmail(email);
		
		int res = lbiz.insert(dto);
		
		if(res > 0) {
			System.out.println("member insert 성공");
			model.addAttribute("dto", dto);
			return "login";
		}else {
			System.out.println("member insert 실패");
			return "register";
		}
	}
	
	

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// QBoard //
	@Autowired
	private QBoardBiz QBBiz;

	@RequestMapping("/qna.do")
	public String qna(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : qna.jsp");
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;
		
		if (res < 5) {
			for (int i = 0; i < res; i++) {
					dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
					dtoss.add(dtos.get(i));
			}
		}

		System.out.println("myno : " + myno);
		System.out.println(dtoss.toString());
		System.out.println("res : " + res);

		model.addAttribute("dtoss", dtoss);
		model.addAttribute("myno", myno);
		model.addAttribute("res", res);

		return "qna";
	}

	@ResponseBody
	@RequestMapping("/ajaxQBoard.do")
	public Map<String, Object> ajaxQBoard(HttpServletRequest httpServletRequest) {
		String myno = httpServletRequest.getParameter("myno").trim();
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		Map<String, Object> rmap = new HashMap<>();
		int mynumber = Integer.parseInt(myno);
		mynumber *= 5;

		if (res - mynumber < 5) {
			for (int i = mynumber; i < res; i++) {
				dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
				dtoss.add(dtos.get(i));
			}
		}

		rmap.put("myno", myno);
		rmap.put("dtoss", dtoss);
		rmap.put("res", res);

		return rmap;
	}

	@RequestMapping("/qnaWrite.do")
	public String qnaWrite(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : qnaWrite.jsp");
		System.out.println("찍히나?");
		if(httpServletRequest.getAttribute("login") == null) {
			return "redirect:login.do";
		}else {
			MemberDto mdto = (MemberDto)httpServletRequest.getAttribute("login");
			model.addAttribute("mdto",mdto);
			return "qnaWrite";
		}
	}
	
	@RequestMapping("/qnaDetail.do")
	public String qnadetail(HttpServletRequest httpServletRequest, Model model) {
		int myno = Integer.parseInt(httpServletRequest.getParameter("myno").trim());
		int pagelength = Integer.parseInt(httpServletRequest.getParameter("pagelength").trim());
		logger.info("[log] : qnaDetail.jsp");
		QBoardDto mdto = QBBiz.selectOne(myno);
		if(httpServletRequest.getAttribute("login") == null) {
			return "redirect:login.do";
		}else {
			//현재 session에 담겨있는 로그인 정보들을 객체로 남아서 qnaDetail페이지로 넘겨줌.
			model.addAttribute("pagelength",pagelength);
			model.addAttribute("mdto",mdto);
			return "qnaDetail";
		}
	}
		
	@RequestMapping("/qnaList.do")
	public String qnaList(HttpServletRequest httpServletRequest, Model model) {
		
		return null;
	}
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "youtube";
	}
	
	@RequestMapping("/mypage.do")
	public String mypage() {
		logger.info("[log] : mypage.jsp");
		return "mypage";
	}

	@RequestMapping("/study.do")
	public String study() {
		logger.info("[log] : study.jsp");
		return "study";
	}

}
