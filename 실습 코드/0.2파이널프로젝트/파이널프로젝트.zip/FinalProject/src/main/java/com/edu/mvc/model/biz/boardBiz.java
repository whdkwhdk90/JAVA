package com.edu.mvc.model.biz;

import java.util.List;

import com.edu.mvc.model.dto.boardDto;

public interface boardBiz {
	public List<boardDto> selectList();
	public boardDto selectOne(int myno);
	public int insert(boardDto dto);
	public int update(boardDto dto);
	public int delete(int myno);
}
