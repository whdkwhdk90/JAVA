package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.stereotype.Service;

import com.edu.mvc.model.dto.boardDto;

@Service
public class boardBizImpl implements boardBiz{

	@Override
	public List<boardDto> selectList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boardDto selectOne(int myno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(boardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(boardDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int myno) {
		// TODO Auto-generated method stub
		return 0;
	}

}
