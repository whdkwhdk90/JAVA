package com.edu.mvc.model.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.edu.mvc.model.dto.MemberDto;

@Repository
public class MemberDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	private String NAMESPACE = "member.";
	
	
	public List<MemberDto> selectList() {

		return null;
	}

	public MemberDto selectOne(MemberDto ldto) {
		MemberDto mdto = new MemberDto();
		mdto = sqlSession.selectOne(NAMESPACE+"selectOne",ldto);
		System.out.println(mdto);
		return mdto;
	}

	public int insert(MemberDto dto) {

		return 0;
	}

	public int update(MemberDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
	
}
