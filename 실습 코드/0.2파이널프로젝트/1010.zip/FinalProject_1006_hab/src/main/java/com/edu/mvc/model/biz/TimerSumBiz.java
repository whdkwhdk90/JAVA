package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.TimerSumDao;
import com.edu.mvc.model.dto.TimerSumDto;

@Service
public class TimerSumBiz {
	
	@Autowired
	private TimerSumDao sumDao;
	
	public List<TimerSumDto> selectAll(String memberid) {
		System.out.println("biz 성공 ");
		return sumDao.selectAll(memberid);
	}
	
	public List<TimerSumDto> selectThisWeek(String memberid) {
		System.out.println("이번주 biz 성공");
		return sumDao.selectThisWeek(memberid);
	}
	
	public List<TimerSumDto> selectMonth(String memberid) {
		System.out.println("한달 (9월) biz 성공");
		return sumDao.selectMonth(memberid);
	}
	
	public TimerSumDto selectOne(String memberid) {
		return sumDao.selectOne(memberid);
	}
	
	public int insert(TimerSumDto sumDto) {
		return sumDao.insert(sumDto);
	}

}
