package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.RecruitAnswerDao;
import com.edu.mvc.model.dto.RecruitAnswerDto;

@Service
public class RecruitAnswerBiz {

	@Autowired
	private RecruitAnswerDao dao;
	
	public List<RecruitAnswerDto> selectList(int rbseq) {
		return dao.selectList(rbseq);
	}

	public int insert(RecruitAnswerDto radto) {
		return dao.insert(radto);
	}

	public int update(RecruitAnswerDto radto) {
		return 0;
	}

	public int delete(String memberid) {
		return 0;
	}
	
	
}
