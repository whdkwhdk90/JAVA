package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dao.TimerDao;
import com.edu.mvc.model.dto.TimerDto;

public class TimerBiz {

	@Autowired
	private TimerDao dao;
	
	public List<TimerDto> selectList() {

		return null;
	}

	public TimerDto selectOne() {

		return null;
	}

	public int insert(TimerDto dto) {

		return 0;
	}

	public int update(TimerDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
	
	
}
