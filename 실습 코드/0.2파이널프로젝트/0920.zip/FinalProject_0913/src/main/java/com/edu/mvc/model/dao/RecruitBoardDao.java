package com.edu.mvc.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dto.RecruitBoardDto;

public class RecruitBoardDao {

	@Autowired
	private SqlSessionTemplate sqlSession;

	private String NAMESPACE = "recruitboard.";

	public List<RecruitBoardDto> selectList() {

		return null;
	}

	public RecruitBoardDto selectOne(String memberid) {

		return null;
	}

	public int insert(RecruitBoardDto dto) {

		return 0;
	}

	public int update(RecruitBoardDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
}
