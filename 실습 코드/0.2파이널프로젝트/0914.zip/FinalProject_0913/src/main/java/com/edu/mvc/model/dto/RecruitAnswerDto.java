package com.edu.mvc.model.dto;

import java.util.Date;

public class RecruitAnswerDto {
	private int rbseq;
	private int raseq;
	private String rbmemberid;
	private String ramemberid;
	private String racontent;
	private Date radate;
	
	public RecruitAnswerDto() {
		super();
	}

	public RecruitAnswerDto(int rbseq, int raseq, String rbmemberid, String ramemberid, String racontent, Date radate) {
		super();
		this.rbseq = rbseq;
		this.raseq = raseq;
		this.rbmemberid = rbmemberid;
		this.ramemberid = ramemberid;
		this.racontent = racontent;
		this.radate = radate;
	}

	public int getRbseq() {
		return rbseq;
	}

	public void setRbseq(int rbseq) {
		this.rbseq = rbseq;
	}

	public int getRaseq() {
		return raseq;
	}

	public void setRaseq(int raseq) {
		this.raseq = raseq;
	}

	public String getRbmemberid() {
		return rbmemberid;
	}

	public void setRbmemberid(String rbmemberid) {
		this.rbmemberid = rbmemberid;
	}

	public String getRamemberid() {
		return ramemberid;
	}

	public void setRamemberid(String ramemberid) {
		this.ramemberid = ramemberid;
	}

	public String getRacontent() {
		return racontent;
	}

	public void setRacontent(String racontent) {
		this.racontent = racontent;
	}

	public Date getRadate() {
		return radate;
	}

	public void setRadate(Date radate) {
		this.radate = radate;
	}

	@Override
	public String toString() {
		return "RecuritAnswerDto [rbseq=" + rbseq + ", raseq=" + raseq + ", rbmemberid=" + rbmemberid + ", ramemberid="
				+ ramemberid + ", racontent=" + racontent + ", radate=" + radate + "]";
	}
	
	
}
