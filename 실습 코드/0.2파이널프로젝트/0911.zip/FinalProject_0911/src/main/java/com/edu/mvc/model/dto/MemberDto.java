package com.edu.mvc.model.dto;

public class MemberDto {
	private String memberid;
	private String memberpw;
	private String name;
	private String email;
	
	public MemberDto() {
		super();
	}
	
	public MemberDto(String memberid, String memberpw, String name, String email) {
		super();
		this.memberid = memberid;
		this.memberpw = memberpw;
		this.name = name;
		this.email = email;
	}
	
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMemberpw() {
		return memberpw;
	}
	public void setMemberpw(String memberpw) {
		this.memberpw = memberpw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "MemberDto [memberid=" + memberid + ", memberpw=" + memberpw + ", name=" + name + ", email=" + email
				+ "]";
	}
	
}
