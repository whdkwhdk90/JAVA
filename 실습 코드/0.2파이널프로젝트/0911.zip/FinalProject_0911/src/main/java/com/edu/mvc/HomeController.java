package com.edu.mvc;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}
	
	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}
		
	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}
			
	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "youtube";
	}
	
	@RequestMapping("/qna.do")
	public String qna() {
		logger.info("[log] : qna.jsp");
		return "qna";
	}
	
	@RequestMapping("/mypage.do")
	public String mypage() {
		logger.info("[log] : mypage.jsp");
		return "mypage";
	}
	
	@RequestMapping("/study.do")
	public String study() {
		logger.info("[log] : study.jsp");
		return "study";
	}
	
}
