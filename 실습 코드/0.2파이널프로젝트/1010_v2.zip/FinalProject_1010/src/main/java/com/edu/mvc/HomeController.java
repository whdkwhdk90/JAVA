package com.edu.mvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.ChatBiz;
import com.edu.mvc.model.biz.MemberBiz;
import com.edu.mvc.model.biz.QAnswerBiz;
import com.edu.mvc.model.biz.QBoardBiz;
import com.edu.mvc.model.biz.RecruitAnswerBiz;
import com.edu.mvc.model.biz.RecruitBoardBiz;
import com.edu.mvc.model.dto.ChatlistDto;
import com.edu.mvc.model.dto.MemberDto;
import com.edu.mvc.model.dto.QAnswerDto;
import com.edu.mvc.model.dto.QBoardDto;
import com.edu.mvc.model.dto.RecruitAnswerDto;
import com.edu.mvc.model.dto.RecruitBoardDto;

@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Resource
	private HttpSession session;

	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("[log] : index.jsp");
		return "index";
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// QBoard //
	@Autowired
	private QBoardBiz QBBiz;
	
	@Autowired
	private ChatBiz cbiz;

	@RequestMapping("/qna.do")
	public String qna(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : qna.jsp");
		int myno = Integer.parseInt(httpServletRequest.getParameter("myno").trim());
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		int mynumber = myno;
		mynumber *= 5;

		if (res < 5) {
			for (int i = 0; i < res; i++) {
				dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
				dtoss.add(dtos.get(i));
			}
		}

		model.addAttribute("dtoss", dtoss);
		model.addAttribute("myno", myno);
		model.addAttribute("res", res);

		return "qna";
	}

	@ResponseBody
	@RequestMapping("/ajaxQBoard.do")
	public Map<String, Object> ajaxQBoard(HttpServletRequest httpServletRequest) {
		int myno = Integer.parseInt(httpServletRequest.getParameter("myno").trim());
		List<QBoardDto> dtos = QBBiz.selectList();
		int res = dtos.size();
		List<QBoardDto> dtoss = new ArrayList<>();
		Map<String, Object> rmap = new HashMap<>();
		int mynumber = myno;
		mynumber *= 5;

		if (res - mynumber < 5) {
			for (int i = mynumber; i < res; i++) {
				dtoss.add(dtos.get(i));
			}
		} else {
			for (int i = mynumber; i < mynumber + 5; i++) {
				dtoss.add(dtos.get(i));
			}
		}

		rmap.put("myno", myno);
		rmap.put("dtoss", dtoss);
		rmap.put("res", res);

		return rmap;
	}

	@RequestMapping("/qnainsertform.do")
	public String qnaInsertForm(HttpServletRequest httpServletRequest, Model model) {
		session = httpServletRequest.getSession();
		logger.info("[log] : qna insert form");
		if (session.getAttribute("logindto") == null) {
			return "redirect:login.do";
		} else {
			MemberDto mdto = (MemberDto) httpServletRequest.getAttribute("login");
			model.addAttribute("mdto", mdto);
			return "qnainsert";
		}
	}

	@RequestMapping("/qnainsertres.do")
	public String qnaInsertRes(QBoardDto qbdto) {
		logger.info("[log] : qna insert res");
		int res = QBBiz.insert(qbdto);

		if (res > 0) {
			return "redirect:qna.do?myno=0";
		} else {
			return "redirect:qnainsertform.do";
		}
	}

	@Autowired
	private QAnswerBiz qabiz;

	@RequestMapping("/qnadetail.do")
	public String qnadetail(HttpServletRequest httpServletRequest, Model model) {
		session = httpServletRequest.getSession();
		int qbseq = Integer.parseInt(httpServletRequest.getParameter("qbseq").trim());
		int pagelength = Integer.parseInt(httpServletRequest.getParameter("pagelength").trim());
		
		logger.info("[log] : qnadetail.jsp");
		QBoardDto mdto = QBBiz.selectOne(qbseq);
	
		if (session.getAttribute("logindto") == null) {
			System.out.println(session.getAttribute("logindto") == null);
			return "redirect:login.do";
		} else {
			// 현재 session에 담겨있는 로그인 정보들을 객체로 남아서 qnadetail페이지로 넘겨줌.
			model.addAttribute("pagelength", pagelength);
			model.addAttribute("qbseq", qbseq);
			model.addAttribute("mdto", mdto);
			
			model.addAttribute("qadto", qabiz.selectList(qbseq));
			
			ChatlistDto cdto = cbiz.selectRoomq(qbseq); 
			model.addAttribute("cdto",cdto);

			return "qnadetail";
		}
	}

	@RequestMapping("/qnadelete.do")
	public String qnadelete(HttpServletRequest httpServletRequest, int myno) {
		session = httpServletRequest.getSession();
		logger.info("[log] : qna delete");

		if (session.getAttribute("logindto") == null) {
			System.out.println(session.getAttribute("logindto") == null);
			return "redirect:login.do";
		} else {
			int res = QBBiz.delete(myno);
			if (res > 0) {
				return "redirect:qna.do?myno=0";
			} else {
				return "redirect:qna.do?myno=0";
			}
		}
	}

	@RequestMapping("/qnaupdateform.do")
	public String qnaUpdateForm(HttpServletRequest httpServletRequest, Model model, int myno, int pagelength) {
		session = httpServletRequest.getSession();
		logger.info("[log] : qna update form");

		if (session.getAttribute("logindto") == null) {
			System.out.println(session.getAttribute("logindto") == null);
			return "redirect:login.do";
		} else {
			model.addAttribute("qbdto", QBBiz.selectOne(myno));
			model.addAttribute("pagelength", pagelength);

			return "qnaupdate";
		}
	}

	@RequestMapping("/qnaupdateres.do")
	public String qnaUpdateRes(HttpServletRequest httpServletRequest, Model model, QBoardDto qbdto, int pagelength) {
		session = httpServletRequest.getSession();
		logger.info("[log] : qna update res");
		
		if (session.getAttribute("logindto") == null) {
			System.out.println(session.getAttribute("logindto") == null);
			return "redirect:login.do";
		} else {
			int res = QBBiz.update(qbdto);
			if (res > 0) {
				return "redirect:qnadetail.do?qbseq="+qbdto.getqbseq()+"&pagelength="+pagelength;
			} else {
				return "redirect:qnaupdateform.do?myno=" + qbdto.getqbseq();
			}
		}
	}

/////////////////////////////////////// qna 댓글 //////////////////////////////////////////////////

	@RequestMapping("/qnaanswerinsert.do")
	public String qnaAnswerInsert(QAnswerDto qadto, int pagelength) {
		logger.info("[log] : qna answer insert");
		int res = qabiz.insert(qadto);
		
		if (res > 0) {
			return "redirect:qnadetail.do?qbseq="+qadto.getQbseq()+"&pagelength="+pagelength;
		} else {
			return "redirect:qna.do?myno=0";
		}
	}
	
	
	@RequestMapping("/qnaanswerupdateform.do")
	public String qnaAnswerUpdateForm(Model model, QAnswerDto qadto, int qaseq, int pagelength) {
		logger.info("[log] : qna answer update form");
		
		model.addAttribute("qadto", qabiz.selectOne(qaseq));
		model.addAttribute("pagelength", pagelength);
		
		return "qnaanswerupdate";
	}
	
	
	@RequestMapping("/qnaanswerupdateres.do")
	public String qnaAnswerUpdateRes(QAnswerDto qadto, int pagelength) {
		logger.info("[log] : qna answer update res");
		System.out.println("컨트롤러에서 update res : "+qabiz.update(qadto));
		int res = qabiz.update(qadto);
		
		if(res>0) {
			return "redirect:qnadetail.do?qbseq="+qadto.getQbseq()+"&pagelength="+pagelength;
		}else {
			return "redirect:qna.do?myno=0";
		}
	}
	
	
	
	@RequestMapping("/qnaanswerdelete.do")
	public String qnaAnswerDelete(int qbseq, int qaseq, int pagelength) {
		int res = qabiz.delete(qaseq);
		
		if(res>0) {
			return "redirect:qnadetail.do?qbseq="+qbseq+"&pagelength="+pagelength;
		}else {
			return "redirect:qna.do?myno=0";
		}
	}
	
	
	
	

////////////////////////////////// 유튜브 게시판  //////////////////////////////////////////////////////////

	@RequestMapping("/youtube.do")
	public String youtube() {
		logger.info("[log] : youtube.jsp");
		return "youtube";
	}

//////////////////////////////////// 스터디 게시판 ////////////////////////////////////////////////////////////////

	@Autowired
	private RecruitBoardBiz rbbiz;

	@Autowired
	private RecruitAnswerBiz rabiz;

	@RequestMapping("/study.do")
	public String study(Model model) {
		logger.info("[log] : study.jsp");
		model.addAttribute("study", rbbiz.selectList());
		return "study";
	}
	
	
	@RequestMapping("/studyinsertform.do")
	public String studyInsertForm() {
		logger.info("[log] : studyinsertform");
		return "studyinsert";
	}

	@RequestMapping("/studyinsertres.do")
	public String studyInsertRes(RecruitBoardDto rbdto) {
		logger.info("[log] : studyinsertres");
		int res = rbbiz.insert(rbdto);
		if (res > 0) {
			return "redirect:study.do";
		} else {
			return "redirect:studyinsertform.do";
		}
	}

	@RequestMapping("/studyupdateform.do")
	public String studyUpdateForm(Model model, int rbseq) {
		logger.info("[log] : study update form");

		model.addAttribute("rbdto", rbbiz.selectOne(rbseq));

		return "studyupdate";
	}

	@RequestMapping("/studyupdateres.do")
	public String studyUpdateRes(RecruitBoardDto rbdto) {
		logger.info("[log] : study update res");
		int res = rbbiz.update(rbdto);
		if (res > 0) {
			return "redirect:studydetail.do?rbseq=" + rbdto.getRbseq();
		} else {
			return "redirect:studyupdateform.do?rbseq=" + rbdto.getRbseq();
		}

	}

	@RequestMapping("delete.do")
	public String delete(int rbseq) {
		logger.info("[log] : study delete");
		int res = rbbiz.delete(rbseq);

		if (res > 0) {
			return "redirect:study.do";
		} else {
			return "redirect:studydetail.do?rbseq=" + rbseq;
		}
	}

	@RequestMapping("/studydetail.do")
	public String studyDetail(Model model, int rbseq) {
		logger.info("[log] : study detail");
		model.addAttribute("rbdto", rbbiz.selectOne(rbseq));
		model.addAttribute("radto", rabiz.selectList(rbseq));

		ChatlistDto cdto = cbiz.selectRooms(rbseq); 
		model.addAttribute("cdto",cdto);
		return "studydetail";
	}

//////////////////////////////////// 스터디 게시판 댓글 //////////////////////////////////////////////	

	@RequestMapping("/studyanswerinsert.do")
	public String studyAnswerInsert(RecruitAnswerDto radto) {
		int res = rabiz.insert(radto);
		if (res > 0) {
			return "redirect:studydetail.do?rbseq=" + radto.getRbseq();
		} else {
			return "redirect:studydetail.do?rbseq=" + radto.getRbseq();
		}
	}
	
	
	@RequestMapping("/studyanswerupdateform.do")
	public String studyAnswerUpdateForm(Model model, RecruitAnswerDto radto, int raseq ) {
		logger.info("[log] : study answer update form");
		
		model.addAttribute("radto", rabiz.selectOne(raseq));
		
		return "studyanswerupdate";
	}
	
	
	@RequestMapping("/studyanswerupdateres.do")
	public String studyAnswerUpdateRes(RecruitAnswerDto radto) {
		logger.info("[log] : study answer update res");
		System.out.println("컨트롤러에서 update res : "+rabiz.update(radto));
		int res = rabiz.update(radto);
		
		if(res>0) {
			return "redirect:studydetail.do?rbseq="+radto.getRbseq();
		}else {
			return "redirect:study.do?";
		}
	}
	
	
	
	@RequestMapping("/studyanswerdelete.do")
	public String studyAnswerDelete(int rbseq, int raseq) {
		int res = rabiz.delete(raseq);
		
		if(res>0) {
			return "redirect:studydetail.do?rbseq="+rbseq;
		}else {
			return "redirect:study.do?";
		}
	}
	
	
	
	
	
	

/////////////////////////////////// 마이 페이지 //////////////////////////////////////////////////////
	
	@Autowired
	MemberBiz mbiz = new MemberBiz();
	
	@Autowired
	QBoardBiz qbiz = new QBoardBiz();
	
	@Autowired
	QAnswerBiz qnabiz = new QAnswerBiz();
	
	@Autowired
	RecruitBoardBiz rbiz = new RecruitBoardBiz();
	
	@Autowired
	RecruitAnswerBiz rnabiz = new RecruitAnswerBiz();
	
	@Autowired
	ChatBiz chbiz = new ChatBiz();
	
	@RequestMapping("/mypage.do")
	public String mypage(HttpServletRequest httpServletRequest, Model model, String memberid) {
		logger.info("[log] : mypage.jsp");
		session = httpServletRequest.getSession();
		
		MemberDto mdto = new MemberDto();
		
		memberid = (String) session.getAttribute("login_id");
		System.out.println(memberid);			//로그인한 아이디 받아오기 
		
		mdto = mbiz.selectMe(memberid);
		
		int qB = qbiz.countMyQ(memberid);
		int rB = rbiz.countMyS(memberid);
		
		int myBoard = qB + rB;
		
		int qnaB = qnabiz.countMyQA(memberid);
		int rnaB = rnabiz.countMyRA(memberid);
		
		int myReply = qnaB + rnaB;
		
		int cB = chbiz.countMyStudy(memberid);
		
		if( memberid.equals( mdto.getMemberid() ) ) {
//			System.out.println(mdto);
//			System.out.println("질문글:"+qB);
//			System.out.println("스터디구인글:"+rB);
//			System.out.println("합치면:" + myBoard);
//			
//			System.out.println("질문댓글: " + qnaB);
//			System.out.println("스터디댓글: " + rnaB);
//			System.out.println("두개 합치면: " + myReply);
			
			System.out.println(cB);
			
			System.out.println("성공");
			model.addAttribute("mdto", mdto);
			model.addAttribute("myBoard", myBoard);
			model.addAttribute("myReply", myReply);
			model.addAttribute("cB", cB);
			
		} else {
			System.out.println("안되넹...");
		}
		
		return "mypage";
	}
	
	
	
	@RequestMapping("/mypageupdate.do")
	public MemberDto mypageUpdate (HttpServletRequest httpServletRequest, MemberDto mDto) {
		logger.info("회원 정보 변경하기");
		
		String memberid = (String) httpServletRequest.getParameter("memberid");
		
		String name = (String) httpServletRequest.getParameter("username");
		String email = (String) httpServletRequest.getParameter("email");
		
		System.out.println(memberid + "," + name + ", " + email);
		
		mDto.setName(name);
		mDto.setEmail(email);
		
		int res = mbiz.update(mDto);
		
		if(res>0) {
			System.out.println("성공@!@@");
			System.out.println(mDto.getName()+", "+mDto.getEmail());
			return mDto;
			
		} else {
			System.out.println("안되네유..");
			return null;
		}
		
	}
	
	
////////////////////////////////// 타이머 ////////////////////////////////////////////////
	

	@RequestMapping("/openTimer.do")
	public String timer() {
		logger.info("[log] : timer.jsp");
		return "timer";
	}
	
	
}
