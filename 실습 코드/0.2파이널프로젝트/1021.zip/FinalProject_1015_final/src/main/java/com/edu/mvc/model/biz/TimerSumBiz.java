package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.mvc.model.dao.TimerSumDao;
import com.edu.mvc.model.dto.TimerSumDto;

@Service
public class TimerSumBiz {
	
	@Autowired
	private TimerSumDao sumDao;
	
	public List<TimerSumDto> selectAll(String memberid) {
		System.out.println("biz 성공 ");
		return sumDao.selectAll(memberid);
	}
	
	public List<TimerSumDto> selectThisWeek(String memberid) {
		System.out.println("이번주 biz 성공");
		return sumDao.selectThisWeek(memberid);
	}
	
	public TimerSumDto selectMon(String memberid) {
		return sumDao.selectMon(memberid);
	}
	public TimerSumDto selectTue(String memberid) {
		return sumDao.selectTue(memberid);
	}
	public TimerSumDto selectWed(String memberid) {
		return sumDao.selectWed(memberid);
	}
	public TimerSumDto selectThu(String memberid) {
		return sumDao.selectThu(memberid);
	}
	public TimerSumDto selectFri(String memberid) {
		return sumDao.selectFri(memberid);
	}
	public TimerSumDto selectSat(String memberid) {
		return sumDao.selectSat(memberid);
	}
	public TimerSumDto selectSun(String memberid) {
		return sumDao.selectSun(memberid);
	}

	public TimerSumDto selectOne(String memberid) {
		return sumDao.selectOne(memberid);
	}
	
	public int insert(TimerSumDto sumDto) {
		return sumDao.insert(sumDto);
	}

}
