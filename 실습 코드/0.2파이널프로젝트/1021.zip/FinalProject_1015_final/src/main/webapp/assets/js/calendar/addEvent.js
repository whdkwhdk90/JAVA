		var eventModal = $('#eventModal');
		var memberid = '<%=((MemberDto)request.getAttribute("logindto")).getMemberid()%>';
		var modalTitle = $('.modal-title');
		var editAllDay = $('#edit-allDay');
		editAllDay.hide();
		var editTitle = $('#edit-title');
		var editStart = $('#edit-start');
		var editEnd = $('#edit-end');
		var editColor = $('#edit-color');
		var editDesc = $('#edit-desc');

		var addBtnContainer = $('.modalBtnContainer-addEvent');
		var modifyBtnContainer = $('.modalBtnContainer-modifyEvent');

		// 새로운 일정 생성
		var newEvent = function (start, end, ind) {
		    $("#contextMenu").hide(); //메뉴 숨김
		    modalTitle.html('새로운 일정');
		    editTitle.val('');
		    editStart.val(start);
		    editEnd.val(end);
		    editDesc.val('');
		    
		    addBtnContainer.show();
		    modifyBtnContainer.hide();
		    eventModal.modal('show');
		    //새로운 일정 저장버튼 클릭
		    
		    $('#save-event').unbind();
		    $('#save-event').on('click', function () {
		    	
		        var eventData = {
		            title: editTitle.val(),
		            start: editStart.val(),
		            end: editEnd.val(),
		            description: editDesc.val(),
		            username: '사나',
		            backgroundColor: editColor.val(),
		            textColor: '#ffffff',
		        };
		      
		        if (eventData.start > eventData.end) {
		            alert('끝나는 날짜가 앞설 수 없습니다.');
		            return false;
		        }

		        if (eventData.title === '') {
		            alert('일정명은 필수입니다.');
		            return false;
		        }
		        //새로운 일정 저장
		        $.ajax({
		            type: "post",
		            url: "addSche.do",
		            data: {
				          	title: editTitle.val(),
				            start: editStart.val(),
				            end: editEnd.val(),
				            description: editDesc.val(),
				            username: memberid,
				            backgroundColor: editColor.val(),
				            textColor: '#ffffff',
				            ind : ind
		            },
		            success: function (response) {
		                //DB연동시 중복이벤트 방지를 위한
		                //$('#calendar').fullCalendar('removeEvents');
		                alert("여기도 안뜸?");
		                $('#calendar').fullCalendar('refetchEvents');
		            }
		        });
		       
		        $("#calendar").fullCalendar('renderEvent', eventData, true);
		        eventModal.find('input, textarea').val('');
		        eventModal.modal('hide');
		    });
		};
		
		$(".addwork").click(function(){
			var ind = -1;
			if($(this).text().length == 2){
				ind = 0;
			}else{
				ind = 1;
			}
			var _today = new Date(); 
			var ftime = _today.format('yyyy-MM-dd HH:mm:ss');
			_today.setHours(_today.getHours()-1);
			var stime = _today.format('yyyy-MM-dd HH:mm:ss');
			newEvent(stime,ftime,ind);
		});

		