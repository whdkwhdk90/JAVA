package com.edu.mvc.model.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.edu.mvc.model.dao.RecruitAnswerDao;
import com.edu.mvc.model.dto.RecruitAnswerDto;

public class RecruitAnswerBiz {

	@Autowired
	private RecruitAnswerDao dao;
	
	public List<RecruitAnswerDto> selectList() {

		return null;
	}

	public RecruitAnswerDto selectOne() {

		return null;
	}

	public int insert(RecruitAnswerDto dto) {

		return 0;
	}

	public int update(RecruitAnswerDto dto) {

		return 0;
	}

	public int delete(String memberid) {

		return 0;
	}
	
	
}
