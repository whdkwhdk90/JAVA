package com.edu.mvc;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.MemberBiz;
import com.edu.mvc.model.dto.MemberDto;

@Controller
public class MemberController {

	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Inject
	private BCryptPasswordEncoder pwdEncoder;

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// LOGIN/REGISTER //
	@Resource
	private MemberBiz lbiz;

	@Resource
	private HttpSession session;

	// 로그인 페이지 접속
	@RequestMapping("/login.do")
	public String login() {
		logger.info("[log] : login.jsp");
		return "login";
	}

	// 회원가입 페이지 접속
	@RequestMapping("/register.do")
	public String register() {
		logger.info("[log] : register.jsp");
		return "register";
	}

	// 로그아웃 시 login페이지로 이동
	@RequestMapping("/logout.do")
	public String logout(HttpServletRequest httpServletRequest, HttpServletResponse response) {
		session.removeAttribute("logindto");
		session.invalidate();
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Cache-control", "no-cache, no-store, must-revalidate");
		response.setHeader("Expires", "0");
		return "redirect:sesschk.do";
	}

	@RequestMapping("/sesschk.do")
	public String sesschk(HttpServletRequest httpServletRequest, HttpServletResponse response) {
		return "/login.do";
	}

	// 로그인 성공시 index페이지 전환
	@RequestMapping(value = "/logind.do", method = RequestMethod.POST)
	public String loginIndex(HttpServletRequest httpServletRequest, HttpServletResponse response) {
		logger.info("[log] : 로그인 -> 인덱스");

		System.out.println(httpServletRequest.getRequestURI());
		System.out.println(httpServletRequest.getRequestURL());

		String memberid = (String) httpServletRequest.getParameter("memberid").trim();
		String memberpw = (String) httpServletRequest.getParameter("memberpw").trim();
		String name = (String) httpServletRequest.getParameter("name").trim();
		String email = (String) httpServletRequest.getParameter("email").trim();

		MemberDto logindto = new MemberDto();
		logindto.setMemberid(memberid);
		logindto.setMemberpw(pwdEncoder.encode(memberpw).trim());
		logindto.setName(name);
		logindto.setEmail(email);

		session.setAttribute("logindto", logindto);
		System.out.println(logindto);

		return "index";

	}

	// 로그인 시도
	@ResponseBody
	@RequestMapping("/ajaxLogin.do")
	public Map<String, Object> loginchk(HttpServletRequest httpServletRequest,
			@RequestParam(value = "memberid") String memberid, @RequestParam(value = "memberpw") String memberpw) {
		System.out.println(memberid);
		System.out.println(memberpw);

		logger.info("[log] : ajaxLogin");
		MemberDto ldto = new MemberDto();
		ldto.setMemberid(memberid.trim());

		System.out.println("ajaxlogin 시도 중");

		Map<String, Object> mmap = new HashMap<>();
		MemberDto mdto = lbiz.selectOne(memberid);
		boolean valid = false;
		if (mdto != null && pwdEncoder.matches(memberpw, mdto.getMemberpw())) {
			mmap.put("mdto", mdto);
			valid = true;
		}
		mmap.put("valid", valid);
		return mmap;
	}

	// 회원가입 시 아이디 중복 여부 체크
	@ResponseBody
	@RequestMapping("/ajaxRegister.do")
	public Map<String, Object> registerchk(HttpServletRequest httpServletRequest,
			@RequestParam(value = "memberid") String memberid) {
		logger.info("[log] : ajaxRegister");
		Map<String, Object> mmap = new HashMap<>();
		MemberDto mdto = lbiz.selectOne(memberid);
		boolean valid = false;
		if (mdto != null) {
			mmap.put("mdto", mdto);
			valid = true;
		}
		mmap.put("valid", valid);
		return mmap;

	}

	// 회원가입 시도
	@RequestMapping("/regchk.do")
	public String regchk(HttpServletRequest httpServletRequest, Model model) {
		logger.info("[log] : regchk");
		String memberid = (String) httpServletRequest.getParameter("memberid").trim();
		String memberpw = (String) httpServletRequest.getParameter("memberpw").trim();
		String name = (String) httpServletRequest.getParameter("name").trim();
		String email = (String) httpServletRequest.getParameter("email").trim();

		MemberDto dto = new MemberDto();
		dto.setMemberid(memberid);
		dto.setMemberpw(pwdEncoder.encode(memberpw).trim());
		dto.setName(name);
		dto.setEmail(email);

		System.out.println("회원가입 시 비밀번호 : " + pwdEncoder.encode(memberpw).trim());

		int res = lbiz.insert(dto);

		if (res > 0) {
			System.out.println("member insert 성공");
			model.addAttribute("dto", dto);
			return "login";
		} else {
			System.out.println("member insert 실패");
			return "register";
		}
	}

	// 회원 정보 일치 여부 확인
	@ResponseBody
	@RequestMapping("/memberidchk.do")
	public boolean memberidchk(HttpServletRequest httpServletRequest, @RequestParam(value = "fname") String name,
			@RequestParam(value = "femail") String email) {
		logger.info("[log] : memberidchk");
		boolean valid = false;
		MemberDto mdto = new MemberDto();
		mdto.setEmail(email);
		mdto.setName(name);
		mdto = lbiz.selectOne(mdto);
		
		if(mdto != null) {
			valid = true;
		}
		return valid;

	}

}
