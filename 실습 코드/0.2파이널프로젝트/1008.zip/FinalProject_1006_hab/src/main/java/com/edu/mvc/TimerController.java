package com.edu.mvc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.edu.mvc.model.biz.TimerEndBiz;
import com.edu.mvc.model.biz.TimerStartBiz;
import com.edu.mvc.model.biz.TimerSumBiz;
import com.edu.mvc.model.dto.TimerEndDto;
import com.edu.mvc.model.dto.TimerStartDto;
import com.edu.mvc.model.dto.TimerSumDto;

@Controller
public class TimerController {
	
	
	private static final Logger logger = LoggerFactory.getLogger(TimerController.class);
	
	
	@Autowired
	private TimerStartBiz startBiz;
	
	@Autowired
	private TimerEndBiz endBiz;
	
	@Autowired
	private TimerSumBiz sumBiz;
	
	private String msg = "timer 통신";
	
	@RequestMapping("/startTimer.do")
	@ResponseBody
	public String timer(HttpServletRequest httpServletRequest, TimerStartDto startDto) {
		logger.info("timer record start");
		
		//HttpSession session = httpServletRequest.getSession();
		
		String memberid = httpServletRequest.getParameter("memberid");
	
		
		startDto.setMemberid(memberid);
		
		if(startBiz.insert(startDto) > 0) {
			logger.info("record start success");
			
			return startDto.getMemberid();
		} else {
			logger.info("record start fail");
			return "실패";
		}
		
	}
	
	
	@RequestMapping("/endNrecordTimer.do")
	@ResponseBody
	public String timer(HttpServletRequest httpServletRequest, TimerEndDto endDto, TimerSumDto sumDto) {
		logger.info("timer record end");
		
		String memberid = httpServletRequest.getParameter("memberid");
		
		endDto.setMemberid(memberid);
		
		int res = 0;
		
		if(endBiz.insert(endDto) > 0) {
			logger.info("record end success");
			
			res = sumBiz.insert(sumDto);
			
			if(res>0) {
				logger.info("디비에도 저장 성공!");
			} else {
				logger.info("디비 저장 실패 ㅜㅜ ");
			}
			
			return sumDto.getMemberid();
		} else {
			logger.info("record end fail");
			return "fail";
		}
		
	}
	/*
	@RequestMapping("/recordTimer.do")
	@ResponseBody
	public String timer(HttpServletRequest httpServletRequest, TimerSumDto sumDto) {
		logger.info("timer record finish");
		
		String memberid = httpServletRequest.getParameter("memberid");
	
		SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd", Locale.KOREA);
		Date date = new Date();
		String today_server = format.format(date);
		//boolean same_date = false;
		
		sumDto.setMemberid(memberid);
		
		int res = sumBiz.insert(sumDto);
		
		if(res>0) {
			logger.info("디비에 성공적으로 저장");
			return sumDto.getMemberid();
		} else {
			logger.info("디비 저장 실패");
			return null;
		}
		
	}
	*/
	
	@RequestMapping("/showSum.do")
	@ResponseBody
	public Map<String, Object> showSum(HttpServletRequest httpServletRequest, TimerSumDto sumDto) {
		logger.info("timer select");
		
		String memberid = httpServletRequest.getParameter("memberid");
		System.out.println("여기");
		
		SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd", Locale.KOREA);
		Date date = new Date();
		
		boolean same_date = false;
		
		String today_server = format.format(date);			//오늘 날짜
		System.out.println("오늘 날짜: " + today_server);
		
		sumDto = sumBiz.selectOne(memberid);		//mapper에서 select해오기 
		System.out.println("여기까지 성공 ");
		System.out.println(sumDto);
		//System.out.println(sumDto.getToday());
	
		boolean ifnull = false;						//Null이면 넘길 거 
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		
		try {
			if( today_server.equals(sumDto.getToday()) && sumDto!=null) {			//불러온 날짜가 오늘이랑 같으면
				same_date=true;
				System.out.println(sumDto.getMemberid() + "/" + sumDto.getTotal_t() + "/" + sumDto.getToday());
				
				ifnull = false;
				map.put("today", sumDto.getToday());
				map.put("total", sumDto.getTotal_t());
				map.put("ifnull", ifnull);
				map.put("same_date", same_date);
			}
		} catch (NullPointerException e) {		//불러온 날짜에 해당하는 컬럼 없어서 null 이면 
			
			ifnull = true;
			map.put("ifnull", ifnull);
			same_date = false;
			map.put("same_date", same_date);
			
			
			
			System.out.println("null입니다 ");
		} 
		
		System.out.println("ifnull: " + ifnull);
		System.out.println("same_date: " + same_date );
		
		return map;
		
	}
	
	@RequestMapping("/showAll.do")
	@ResponseBody
	public Map<String, Object> showResult(HttpServletRequest httpServletRequest, TimerSumDto sumDto) {
		logger.info("시간을 모두 불러오기");
		String memberid = httpServletRequest.getParameter("memberid");
		
		String msg_s = "List 불러오기 성공";
		String msg_f = "List 불러오기 실패";
 		
		List<TimerSumDto> sumAll = sumBiz.selectAll(memberid);		//비어있다..?!
		System.out.println("여기까지 성공");
		//System.out.println(sumAll);
		
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("msg_s", msg_s);
		map.put("msg_f", msg_f);
		map.put("sumList", sumAll);
		
		//System.out.println(map.get("sumList"));
		return map;
		
		
	}
	
	

	@RequestMapping("/showThisWeek.do")
	@ResponseBody
	public Map<String, Object> showThisWeek(HttpServletRequest httpServletRequest, TimerSumDto sumDto) {
		logger.info("시간을 모두 불러오기");
		String memberid = httpServletRequest.getParameter("memberid");
		
		String msg_s = "이번주 List 불러오기 성공";
		String msg_f = "이번주 List 불러오기 실패";
 		
		List<TimerSumDto> sumTW = sumBiz.selectThisWeek(memberid);		//비어있다..?!
		System.out.println("여기까지 성공");
		//System.out.println(sumAll);
		
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("msg_s", msg_s);
		map.put("msg_f", msg_f);
		map.put("sumTWList", sumTW);
		
		//System.out.println(map.get("sumList"));
		return map;
		
		
	}
	/*
	@RequestMapping("/selectMonth.do")
	@ResponseBody
	public Map<String, Object> selectMonth(HttpServletRequest httpServletRequest, TimerSumDto sumDto) {
		logger.info("select month");
		String memberid = httpServletRequest.getParameter("memberid");
		
		List<TimerSumDto> list = sumBiz.selectMonth(memberid);
		System.out.println("한달 불러오는 biz 성공");
		
		System.out.println(list);
		
		
		
		return null;
	}
	
	*/


}
