package com.edu.mvc.model.dto;

import java.util.Date;

public class TimerDto {
	private String memberid;
	private Date mydate;
	private Date stime;
	private Date ftime;
	
	public TimerDto() {
		super();
	}

	public TimerDto(String memberid, Date mydate, Date stime, Date ftime) {
		super();
		this.memberid = memberid;
		this.mydate = mydate;
		this.stime = stime;
		this.ftime = ftime;
	}

	public String getMemberid() {
		return memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public Date getMydate() {
		return mydate;
	}

	public void setMydate(Date mydate) {
		this.mydate = mydate;
	}

	public Date getStime() {
		return stime;
	}

	public void setStime(Date stime) {
		this.stime = stime;
	}

	public Date getFtime() {
		return ftime;
	}

	public void setFtime(Date ftime) {
		this.ftime = ftime;
	}

	@Override
	public String toString() {
		return "TimerDto [memberid=" + memberid + ", mydate=" + mydate + ", stime=" + stime + ", ftime=" + ftime + "]";
	}
	
}
