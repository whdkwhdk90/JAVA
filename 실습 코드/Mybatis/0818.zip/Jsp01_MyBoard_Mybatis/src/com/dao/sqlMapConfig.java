package com.dao;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class sqlMapConfig {
	
	private SqlSessionFactory sqlSessionFactory;
	
	public SqlSessionFactory getSqlSessionFactory() {
		//Config.xml 의 경로
		
		String resource = "db/Config.xml";
		
		try {
			//config.xml에서 설정한 정보들을 reader를 통해 읽어옴.
			Reader reader = Resources.getResourceAsReader(resource);
			
			//관련 sqlSessionFactory 생성
			//sqlSession을 위해 sqlSessionFactory가 필요하고 그 factory를 만들어줌.
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return sqlSessionFactory;
	}
	
	
	
}
