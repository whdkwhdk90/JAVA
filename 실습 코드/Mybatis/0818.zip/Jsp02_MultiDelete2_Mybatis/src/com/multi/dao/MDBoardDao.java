package com.multi.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import com.multi.dto.MDBoardDto;

public class MDBoardDao extends SqlMapConfig{

	private String namespace = "com.my.multi.";
	
	//게시판 목록
	public List<MDBoardDto> selectAll(){
		List<MDBoardDto> res = new ArrayList<>();
		SqlSession session = null;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res = session.selectList(namespace+"selectAll");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return res;
	}
	
	public MDBoardDto selectOne(int seq) {
		//1. Mapper 파일 완성
		// -resultMap을 활용하여 select한 결과값 리턴받기
		// -parameter는 seq
		// -sql문의 id는 selectOne
		
		//2. Dao에서 해당 Mapper파일의 쿼리문을 실행한 후 결과값을 리턴
		MDBoardDto res = new MDBoardDto();
		SqlSession session = null;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res= session.selectOne(namespace+"selectOne",seq);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return res;
	}
	
	//다중 삭제(한번에 처리)
		public int multiDelete(String[] seq) {
			int count = 0 ;
			Map<String,String[]> map = new HashMap<>();
			map.put("seq", seq);
			
			SqlSession session = null;
			
			try {
				session = getSqlSessionFactory().openSession(true);
				count = session.delete(namespace+"muldel",map);
				
				
				//선택한 게시글들의 번호들을 다 지웠을 경우
				if(count == seq.length){
					session.commit();
				}			
		
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				session.close();
			}
			
			return count;
		}

	
	public int insert(MDBoardDto dto){
		int res = 0;
		SqlSession session = null;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res = session.insert(namespace+"insert",dto);
			
			if(res>0) {
				session.commit();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		
		return res;
	}
	

	//글 수정
	public int update(MDBoardDto dto) {
		int res = 0;
		SqlSession session = null;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res = session.update(namespace+"update",dto);
			
			if(res>0) {
				session.commit();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return res;
	}
	
	//글 삭제
	public int delete(int seq) {
		SqlSession session = null;
		int res = 0;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res = session.delete(namespace+"delete",seq);
			
			if(res>0) {
				session.commit();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return res;
	}


	

	//다중 삭제(여러번 처리)
//	public int multiDelete(String[] seq) {
//		
//		Connection con = getConnection();
//		PreparedStatement pstm = null;
//		int res = 0;
//		int[] cnt = new int[seq.length];
//		String sql = " DELETE FROM MDBOARD WHERE SEQ=? ";
//		
//		try {
//			pstm = con.prepareStatement(sql);
//			
//			for(int i=0; i<seq.length;i++) {
//				
//				pstm.setString(1, seq[i]);
//				System.out.println(i+"번째 "+pstm);
//				
//				cnt[i]=pstm.executeUpdate();
//				if(cnt[i]>0) 
//				{
//					System.out.println(res);
//					res++;
//				}	
//			}
//			if(seq.length==res) {
//				commit(con);
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//		return res;
//		
//	}
	
	
	
}



















