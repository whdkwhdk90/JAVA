package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.MyBoardDto;


public class MyBoardDao extends sqlMapConfig{
	private String namespace = "com.myboard.";
	
	
	public List<MyBoardDto> selectall() {
		List<MyBoardDto> res = new ArrayList<>();
		
		SqlSession session = null;
		//sql세션객체 생성
		session = getSqlSessionFactory().openSession(true);
		
		res = session.selectList(namespace+"selectAll");
							//"com.myboard.selectAll"
		session.close();
		
		return res;
	}
	
	public MyBoardDto selectone(int myno) {
		
		SqlSession session = null;
		MyBoardDto res = null;
		
		try {
			session = getSqlSessionFactory().openSession(true);
			res = session.selectOne(namespace+"selectOne",myno);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		
		return res;
	}
	
	public int insert(MyBoardDto dto) {
		return 0;
	}
	
	public int delete(int myno) {
		return 0;
	}
	
	
	public int update(MyBoardDto dto) {
		return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
