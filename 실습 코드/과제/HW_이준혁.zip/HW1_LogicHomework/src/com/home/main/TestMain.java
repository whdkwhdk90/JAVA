package com.home.main;

import com.home.view.Menu;

public class TestMain {
	public static void main(String[] args) {
		new Menu().displayMenu();   //과제 1 해결
	}
}
