package com.testIO.controller;

import java.util.Vector;

public interface WordSearchInterface {
	//파일로부터 한줄씩 문자열을 읽어서 Vector<String>에 저장한다.
	void readFile(String fileName);
	//저장한 Vector<String>으로부터 한줄씩 문자열을 가져와서
	//indexOF(word) 메소드를 이용하여 포함 단어/문자의 포함 유무를 확인한 후
	//저장한 Vector<Integer> 에 단어가 발견된 문장의 줄 번호를 저장한다.
	Vector<Integer> searchWord(String word);
	//Vector<Integer> 에 저장된 줄번호를 하나씩 읽고
	//Vector<String> 으로부터 해당 줄번호의 문장을 출력한다.
	void printLines(Vector<Integer> noVector);
}
