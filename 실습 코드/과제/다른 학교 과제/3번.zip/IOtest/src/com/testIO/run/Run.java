package com.testIO.run;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.testIO.controller.FileIOTest;

public class Run {
	public static void main(String[] args) {

		try (BufferedReader br = new BufferedReader//
		(new InputStreamReader(System.in))) {
			System.out.println("전체 경로명이 아닌 파일 이름만 입력하는 경우, 파일은 프로젝트 폴더에 있어야 합니다.");
			System.out.print("대상 파일명 입력>> ");
			String str = br.readLine();
			FileIOTest fiot = new FileIOTest();
			fiot.readFile(str);
			while (true) {
				System.out.print("검색할 단어나 문장>> ");
				str = br.readLine();
				if (str.equals("exit?")) {
					System.out.println("프로그램을 종료합니다.");
					break;
				} else {
					fiot.printLines(fiot.searchWord(str));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
