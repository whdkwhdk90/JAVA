package com.testIO.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class FileIOTest implements WordSearchInterface {
	Vector<String> vs = new Vector<>();
	Vector<Integer> noVector = new Vector<>();

	@Override
	public void readFile(String fileName) {

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String str = "";
			while ((str = br.readLine()) != null) {
				vs.add(str);
			}
			System.out.println(vs);
		} catch (

		FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 저장한 Vector<String>으로부터 한줄씩 문자열을 가져와서
	// indexOF(word) 메소드를 이용하여 포함 단어/문자의 포함 유무를 확인한 후
	// 저장한 Vector<Integer> 에 단어가 발견된 문장의 줄 번호를 저장한다.
	@Override
	   public Vector<Integer> searchWord(String word) {
	      String str = "";
	      for (int i = 0; i < vs.size(); i++) {
	         if (vs.get(i).contains(word)) {
	            str = vs.get(i);
	            noVector.add(vs.indexOf(str));
	         }
	      }
	      return noVector;
	   }

	// Vector<Integer> 에 저장된 줄번호를 하나씩 읽고
	// Vector<String> 으로부터 해당 줄번호의 문장을 출력한다.
	@Override
	public void printLines(Vector<Integer> noVector) {
		for (int i = 0; i < noVector.size(); i++) {
			try {
				System.out.println((noVector.get(i) + 1)//
						+ ". " + vs.get(noVector.get(i)));
			} catch (ArrayIndexOutOfBoundsException e) {

			}
		}
		noVector.removeAll(noVector);
	}
}