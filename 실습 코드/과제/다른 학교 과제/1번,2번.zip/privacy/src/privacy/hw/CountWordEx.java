package privacy.hw;

public class CountWordEx{
	public static void main(String[] args) {
		 new CountWord();
	}
}
