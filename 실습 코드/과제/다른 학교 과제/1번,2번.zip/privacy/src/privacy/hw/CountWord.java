package privacy.hw;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;


public class CountWord implements CountWordInterface{
         Scanner sc = new Scanner(System.in);
         String path = CountWordEx.class.getResource("").getPath();
         StringTokenizer st = null;
         int cnt = 0;
         
         boolean head = true;
         
         ArrayList arr = new ArrayList();
         ArrayList word = new ArrayList();
         
         
         public CountWord() {
            try {
               System.out.println("단어들의 배열을 1줄에 7개의 단어씩 나열합니다.");
               System.out.println("****************************************************************");
               //입력 객체 생성
               File file = new File(path+"input.txt");
               //입력 스트림 생성
               FileReader fr = new FileReader(file);
               //입력 버퍼 생성
               BufferedReader br = new BufferedReader(fr);
               String line = "";
               while( (line = br.readLine()) != null) {
                  System.out.println(line);
               }
               makeWordArray();
               System.out.println("****************************************************************");
               while(true) {
               System.out.println("특정 문자로 시작하거나 끝나는 단어를 검색합니다.");
               System.out.print("검색하려는 문자를 입력하시오. 종료하려면 \"exit\"을 입력하시오 >> ");
                  String instr = sc.next();
                  if(instr.equals("exit")) {
                     System.out.println("프로그램을 종료합니다.");
                     return;
                  }else {
                	  System.out.println("\n"+instr+"로 시작하는 단어를 검색합니다.");
                     word = new ArrayList();
                     head=true;
                     for(int i=0;i<arr.size();i++) {
                        
                        char[] wordcheck = arr.get(i).toString().toUpperCase().toCharArray();
                 
                        
                        if(wordcheck[0] == instr.toUpperCase().charAt(0)) {
                           word.add(arr.get(i));
                        }
                  
                     }
                     
                     cnt = countCWord(instr.charAt(0),head);
                     
                     printWordArray();
                     System.out.println(instr+"로 시작하는 단어의 수는 "+cnt+" 입니다.\n");
                     
                     System.out.println(instr+"로 끝나는 단어를 검색합니다.");
                   word = new ArrayList();
                     head = false;                    
                     for(int i=0;i<arr.size();i++) {                       
                        char[] wordcheck = arr.get(i).toString().toUpperCase().toCharArray();
                        
                        if(wordcheck[arr.get(i).toString().length()-1] == instr.toUpperCase().charAt(0)) {
                           word.add(arr.get(i));
                        }
                        
                        
                     }
                     cnt = countCWord(instr.charAt(0),head);                   
                     printWordArray();
                     System.out.println(instr+"로 끝나는 단어의 수는 "+cnt+" 입니다. \n");
                  }   
               }   
            } catch (FileNotFoundException e) {
               e.printStackTrace();
            } catch (IOException e) {
               e.printStackTrace();
            }
            
            
         }

         
         
      @Override
      public void makeWordArray() {
         File file = new File(path+"input.txt");
         //입력 스트림 생성
         FileReader fr;
         
      try {
         fr = new FileReader(file);
          //입력 버퍼 생성
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            while( (line = br.readLine()) != null) {
               
               String[] str = line.split(" ");
               for(int i=0;i<str.length;i++) {
                  arr.add(str[i]);
               }
               
            }
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      } catch (IOException e) {
         e.printStackTrace();
      }
        
         
      }   //단어들의 배열 생성


      @Override
      public void printWordArray() {
         for(int i=0;i<word.size();i++) {
            System.out.print(word.get(i)+" ");
         }
         
         System.out.println();
      }//단어들의 배열 출력

      @Override
      public int countCWord(char c, boolean head) {
         
         cnt = word.size();
         
         return cnt;
      }// head ==true 이면 c로 시작하는 단어
      //==false 이면 c로 끝나는 단어
      //총 개수 구하여 리턴







   
}