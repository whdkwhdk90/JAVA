package privacy.hw;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class search {
   public static void main(String[] args) {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      BufferedWriter bw = null;
      FileWriter fw = null;
      FileReader fr = null;
      String fname = "";
      String fname2 = "";
      String str ="";
      String[] sarr = null;
      int cnt1 = 0;
      int cnt2 = 0;
      int cnt3 = 0;
      try {
         System.out.print("입력 파일명 : ");
         fname = br.readLine();
         fw = new FileWriter(fname,true);
         System.out.print("출력 파일명 : ");
         fname2 = br.readLine();
         
         fr = new FileReader(fname);
         int val;
         while((val = fr.read()) != -1) {
            if(((char)val <= 'z' && (char)val >= 'a')
               || ((char)val <= 'Z' && (char)val >= 'A')   )
            cnt1++;
         }
         
         //단어 수 세는 문장
         br = new BufferedReader(new FileReader(fname));
         while((str = br.readLine()) != null) {
            sarr = str.split(",|//?|!| ");
            cnt2 = cnt2 + sarr.length;
         }
   
         //문장 수 갯수 세는 문장
         br = new BufferedReader(new FileReader(fname));
         while((str = br.readLine()) != null) {
            sarr = str.split(",|//?|!");
            cnt3 = cnt3 + sarr.length;
         }
      
           
      } catch (IOException e) {
         System.out.println("파일이 없습니다. 다시 입력해주세요");
         e.printStackTrace();
      }
      
      try {
         bw = new BufferedWriter(new FileWriter(fname2));
         bw.write("문자 수는 "+cnt1+"개 입니다. \n");
          bw.write("단어 수는 "+cnt2+"개 입니다. \n");
          bw.write("문장 수는 "+cnt3+"개 입니다.");
       
          System.out.println("문자 수는 "+cnt1+"개 입니다.");
          System.out.println("단어 수는 "+cnt2+"개 입니다.");
          System.out.println("문장 수는 "+cnt3+"개 입니다.");
         
      }catch (IOException e) {
          e.printStackTrace();
       }finally {
          try {
             bw.close();
          } catch (IOException e) {
             e.printStackTrace();
          }
       }
   }   
   
}