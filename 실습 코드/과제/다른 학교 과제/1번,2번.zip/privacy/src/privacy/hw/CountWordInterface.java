package privacy.hw;

public interface CountWordInterface {

	public void makeWordArray();
	public void printWordArray();
	public int countCWord(char c, boolean head);
}
