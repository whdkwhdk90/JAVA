package com.hw2;

import com.hw2.controller.SpaceUpper;

public class Run {

	public static void main(String[] args) {

		SpaceUpper su = new SpaceUpper();
		su.spaceToUpper();
		
		
	}

}
