package com.hw3.controller;

import java.util.Calendar;

public class SetDate {

	
public SetDate() {}

public String todayPrint() {
	Calendar calendar = Calendar.getInstance();
	
	calendar.set(2020,4-1,13);
	
	int year = calendar.get(calendar.YEAR);
	int month = calendar.get(calendar.MONTH)+1;
	int date = calendar.get(calendar.DATE);
	int hour = calendar.get(calendar.HOUR_OF_DAY);
	int min = calendar.get(calendar.MINUTE);
	int sec = calendar.get(calendar.SECOND);
	
	return year+"년 "+month+"월 "+date+"일 "+hour+"시간 "+min+"분 "+sec+"초";
}
	
public String setDay() {
	
	Calendar calendar = Calendar.getInstance();
	
	calendar.set(2020,4-1,13);
	
	calendar.add(calendar.YEAR, -9);
	int year =calendar.get(calendar.YEAR);
	calendar.add(calendar.MONTH, -1);
	int month = calendar.get(calendar.MONTH)+1;
	calendar.add(calendar.DATE, 8);
	int date = calendar.get(calendar.DATE);
	int dayOfWeek = calendar.get(calendar.DAY_OF_WEEK);
	
	
	System.out.print(year+"년 "+month+"월 "+date+"일 ");
	
	switch(dayOfWeek) {
	
	case 1:
		System.out.println("일요일");
		break;
	case 2:
		System.out.println("월요일");
		break;
	case 3:
		System.out.println("화요일");
		break;
	case 4:
		System.out.println("수요일");
		break;
	case 5:
		System.out.println("목요일");
		break;
	case 6:
		System.out.println("금요일");
		break;
	case 7:
		System.out.println("토요일");
		break;	
		
	}
	

	return "";
}


}
