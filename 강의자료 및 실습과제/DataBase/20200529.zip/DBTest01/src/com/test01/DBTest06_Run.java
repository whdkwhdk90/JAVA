package com.test01;

public class DBTest06_Run {

	public static void main(String[] args) {
//			new DBTest06().selectAll();
//			new DBTest06().delete();
//			new DBTest06().insert();
//			new DBTest06().selectOne();
			
	}

}
