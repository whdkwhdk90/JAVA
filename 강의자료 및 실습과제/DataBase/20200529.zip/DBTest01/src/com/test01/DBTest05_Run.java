package com.test01;

public class DBTest05_Run {

	public static void main(String[] args) throws Exception {
//		new DBTest05().insert();
//		new DBTest05().delete();
//		new DBTest05().selectAll();
		new DBTest05().selectOne();
		
		
	}

}
