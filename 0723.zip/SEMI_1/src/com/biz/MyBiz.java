package com.biz;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.commit;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.List;

import com.dao.LoginDao;
import com.dao.foodDao;
import com.dao.memberDao;
import com.dao.popularityDao;
import com.dto.SnsMemberDto;
import com.dto.foodDto;
import com.dto.memberDto;
import com.dto.popularityDto;

public class MyBiz {

	private memberDao ddao = new memberDao();
	private popularityDao pdao = new popularityDao();
	private foodDao fdao = new foodDao();
	private static LoginDao ldao = new LoginDao();

	// -----------------------------------------------------------------------------

	// --------------------------member-----------------------------------------------

	public int insert(memberDto member) {
		return ddao.insert(member);
	}
	public memberDto selectOne(int mno) {
		return ddao.selectOne(mno);
	}

	// -------------------------------------------------------------------------------

	// -------------------------------popularity--------------------------------------

	// 연령무관성별무관
	public List<popularityDto> selectRankAllAll() {

		return pdao.selectRankAllAll();
	}
	// 연령무관남자만
	public List<popularityDto> selectRankAllM() {

		return pdao.selectRankAllM();
	}
	// 연령무관여자만
	public List<popularityDto> selectRankAllF() {

		return pdao.selectRankAllF();
	}
	// 연령10대성별무관
	public List<popularityDto> selectRank10All() {

		return pdao.selectRank10All();
	}
	// 연령10대남자만
	public List<popularityDto> selectRank10M() {

		return pdao.selectRank10M();
	}
	// 연령10대여자만
	public List<popularityDto> selectRank10F() {

		return pdao.selectRank10F();
	}
	// 연령20대성별무관
	public List<popularityDto> selectRank20All() {

		return pdao.selectRank20All();
	}
	// 연령20대남자만
	public List<popularityDto> selectRank20M() {

		return pdao.selectRank20M();
	}
	// 연령20대여자만
	public List<popularityDto> selectRank20F() {

		return pdao.selectRank20F();
	}
	// 연령30대성별무관
	public List<popularityDto> selectRank30All() {

		return pdao.selectRank30All();
	}
	// 연령30대남자만
	public List<popularityDto> selectRank30M() {

		return pdao.selectRank30M();
	}
	// 연령30대여자만
	public List<popularityDto> selectRank30F() {

		return pdao.selectRank30F();
	}
	// 연령40대이상성별무관
	public List<popularityDto> selectRank40All() {

		return pdao.selectRank40All();
	}
	// 연령40대이상남자만
	public List<popularityDto> selectRank40M() {

		return pdao.selectRank40M();
	}
	// 연령40대이상여자만
	public List<popularityDto> selectRank40F() {

		return pdao.selectRank40F();
	}

	   // 좋아요 
	   public int insert(popularityDto dto) {
	      return pdao.insert(dto);
	   }
	   
	   // 좋아요 취소
	   public int delete(int fno, int mno) {
	      return pdao.delete(fno, mno);
	   }
	   
	   // 좋아요 여부에 따른 화면 출력
	   public List<popularityDto> popYN(int mno) {
	      return pdao.popYN(mno);
	   }   

	// ---------------------------------------------------------------------------------

	// ------------------------------food-----------------------------------------------

	 // 나라별 음식 페이지 오픈
	   public List<foodDto> selectAll() {
	      return fdao.selectAll();
	   }

	   // JOIN - 조리법 받아오기
	   public List<foodDto> getcooking() {
	      return fdao.getcooking();
	   }

	   // 상세 레시피 페이지 오픈
	   public foodDto selectdetil(int fno) {
	      return fdao.selectdetil(fno);
	   }

	// ------------------------------------------------------------------------------

	// ------------------------------login/regist------------------------------------
	//id체크 Biz
	   public static memberDto selectUser(String mid) {
	      Connection con = getConnection();
	      memberDto dto = ldao.selectUser(mid,con);
	      
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return dto;
	   }
	   
	   public static String idChk(String id) {
	      
	      Connection con = getConnection();
	      String res = ldao.idChk(id,con);
	      
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return res;
	   }
	   
	   //회원 가입 Biz
	   public static boolean insertUser(memberDto dto) {
	      Connection con = getConnection();
	      boolean valid = false;
	      
	      int res = ldao.insertUser(dto,con);
	      
	      if(res>0) {
	         commit(con);
	         valid = true;
	      }
	         
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return valid;
	   }
	   public static memberDto login(String id, String pw) {
	      Connection con = getConnection();
	      memberDto dto = ldao.login(id, pw,con);
	      
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return dto;
	   }
	   
	   public static SnsMemberDto sidchk(int i) {
	      Connection con = getConnection();
	      
	      SnsMemberDto sdto = ldao.sidchk(i,con);
	      
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      
	      return sdto;
	   }
	   public static int insertSNSUser(SnsMemberDto kdto, String sql) {
	      Connection con =getConnection();
	      int res = ldao.insertSNSUser(con,kdto,sql);
	      
	      try {
	         close(con);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return res;
	   }
	   
	// ------------------------------------------------------------------------------

}