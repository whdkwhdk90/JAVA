package com.dao;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.commit;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.popularityDto;

public class popularityDao {

   //나이무관성별무관
      public List<popularityDto> selectRankAllAll() {
         
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.RANK,F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO) \"COUNT\", \r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID  AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. AllAll query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      
      
      
      //나이무관남자만

      public List<popularityDto> selectRankAllM() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.RANK,F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(M_GENDER ) DESC ) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_GENDER ='M'\r\n" + 
               "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. AllM query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      
      //나이무관여자만
      public List<popularityDto> selectRankAllF() {
          Connection con = getConnection();
          PreparedStatement pstm = null;
          ResultSet rs = null;
          List<popularityDto> res = new ArrayList<popularityDto>();
          
          String sql ="SELECT A.RANK,F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
                "FROM (SELECT F_NO  , COUNT(F_NO) \"COUNT\",\r\n" + 
                "ROW_NUMBER() OVER(ORDER BY COUNT(M_GENDER ) DESC ) \"RANK\"\r\n" + 
                "FROM POPULARITY P\r\n" + 
                "WHERE M_GENDER ='F'\r\n" + 
                "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
                "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
                "ORDER BY \"RANK\" ASC";
          
          try {
             pstm=con.prepareStatement(sql);
             System.out.println("03. AllF query 준비: " + sql);
             
             rs=pstm.executeQuery();
             System.out.println("04.query 실행 및 리턴");
             
             while(rs.next()) {
                popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
                res.add(tmp);
             }
          } catch (SQLException e) {
             System.out.println("3/4단계 오류");
             e.printStackTrace();
          } finally {
             close(rs);
             close(pstm);
             close(con);
             System.out.println("05. db종료\n");
          }

          return res;
       }
      
      //나이10대성별무관
      public List<popularityDto> selectRank10All() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
                "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
                "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
                "FROM POPULARITY P\r\n" + 
                "WHERE M_AGE>=10 AND M_AGE <20\r\n" + 
                "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
                "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
                "ORDER BY \"RANK\" ASC";
               
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 10All query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      
      //나이10대남자만
      
      public List<popularityDto> selectRank10M() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.RANK,F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  ,  COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=10 AND M_AGE <20 AND M_GENDER ='M'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 10M query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이10대여자만
      
      
      public List<popularityDto> selectRank10F() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.RANK,F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
                "FROM (SELECT F_NO  ,  COUNT(F_NO ) \"COUNT\",\r\n" + 
                "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
                "FROM POPULARITY P\r\n" + 
                "WHERE M_AGE>=10 AND M_AGE <20 AND M_GENDER ='F'\r\n" + 
                "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
                "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
                "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 10F query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이20대성별무관
      
      public List<popularityDto> selectRank20All() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=20 AND M_AGE <30\r\n" + 
               "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 20All query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이20대남자만
      public List<popularityDto> selectRank20M() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=20 AND M_AGE <30 AND M_GENDER ='M'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 20M query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이20대여자만
      
      public List<popularityDto> selectRank20F() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR , NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=20 AND M_AGE <30 AND M_GENDER ='F'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 20F query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이30대성별무관
      public List<popularityDto> selectRank30All() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=30 AND M_AGE <40\r\n" + 
               "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 30All query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이30대남자만
      public List<popularityDto> selectRank30M() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=30 AND M_AGE <40 AND M_GENDER ='M'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 30M query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이30대여자만
      public List<popularityDto> selectRank30F() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
                "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
                "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
                "FROM POPULARITY P\r\n" + 
                "WHERE M_AGE>=30 AND M_AGE <40 AND M_GENDER ='F'\r\n" + 
                "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
                "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
                "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 30F query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이40대이상성별무관
      public List<popularityDto> selectRank40All() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=40\r\n" + 
               "GROUP BY F_NO) A, FOOD ,NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 40All query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      //나이40대이상남자만
      public List<popularityDto> selectRank40M() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR,NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=40 AND M_GENDER ='M'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 40M query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }
      
      //나이40대이상여자만
      public List<popularityDto> selectRank40F() {
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         
         String sql ="SELECT A.\"RANK\",F_NAME,IMGDIR , NATION,A.COUNT\r\n" + 
               "FROM (SELECT F_NO  , COUNT(F_NO ) \"COUNT\",\r\n" + 
               "ROW_NUMBER() OVER(ORDER BY COUNT(F_NO ) DESC) \"RANK\"\r\n" + 
               "FROM POPULARITY P\r\n" + 
               "WHERE M_AGE>=40 AND M_GENDER ='F'\r\n" + 
               "GROUP BY F_NO) A, FOOD , NATION\r\n" + 
               "WHERE A.F_NO=FOOD.F_NO AND FOOD.NATION_ID =NATION.NATION_ID AND \"RANK\"<11\r\n" + 
               "ORDER BY \"RANK\" ASC";
         
         try {
            pstm=con.prepareStatement(sql);
            System.out.println("03. 40F query 준비: " + sql);
            
            rs=pstm.executeQuery();
            System.out.println("04.query 실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               res.add(tmp);
            }
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("05. db종료\n");
         }

         return res;
      }

      
      
      
      // 좋아요
      public int insert(popularityDto dto) {
         
         Connection con = getConnection();
         PreparedStatement pstm = null;
         int res = 0;
         String sql = "INSERT INTO POPULARITY VALUES(?,?,?,?)";
         
         try {
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, dto.getFno());
            pstm.setInt(2, dto.getMno());
            pstm.setInt(3, dto.getMage());
            pstm.setString(4, dto.getMgender());
            System.out.println("3. 쿼리준비: "+sql);
            
            res = pstm.executeUpdate();
            System.out.println("4. 쿼리실행 및 리턴");
            
            if(res>0) {
               commit(con);
            }
            
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(pstm);
            close(con);
            System.out.println("5. db종료 \n");
         }
         
         return res;
      }
      
      
      // 좋아요 취소
      public int delete(int fno, int mno) {
         
         Connection con = getConnection();
         PreparedStatement pstm = null;
         int res = 0;
         String sql = "DELETE FROM POPULARITY WHERE F_NO=? AND M_NO=?";
         
         try {
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, fno);
            pstm.setInt(2, mno);
            System.out.println("3. 쿼리준비: "+sql);
            
            res = pstm.executeUpdate();
            System.out.println("4. 쿼리실행 및 리턴");
            
            if(res>0) {
               commit(con);
            }
            
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(pstm);
            close(con);
            System.out.println("5. db종료 \n");
         }
         
         return res;
      }

      
      // 좋아요 여부 확인
      public List<popularityDto> popYN(int mno) {
         
         Connection con = getConnection();
         PreparedStatement pstm = null;
         ResultSet rs = null;
         List<popularityDto> res = new ArrayList<popularityDto>();
         String sql = "SELECT * FROM POPULARITY WHERE M_NO=?";
         
         try {
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, mno);
            System.out.println("3. 쿼리준비: "+sql);
            
            rs = pstm.executeQuery();
            System.out.println("4. 쿼리실행 및 리턴");
            
            while(rs.next()) {
               popularityDto tmp = new popularityDto();
               tmp.setFno(rs.getInt(1));
               tmp.setMno(rs.getInt(2));
               tmp.setMage(rs.getInt(3));
               tmp.setMgender(rs.getString(4));
               
               res.add(tmp);
            }
            
         } catch (SQLException e) {
            System.out.println("3/4단계 오류");
            e.printStackTrace();
         } finally {
            close(rs);
            close(pstm);
            close(con);
            System.out.println("5. db종료 \n");
         }
         
         /*
         회원이 로그인 했을 때 해당 회원번호(mno)로 select해서 fno 반환받기
         이미 인기도 테이블에 있는 음식이면 채운하트, 아니면 빈하트 표시
         fno 반환 여러개 받으니까 list에 넣고 fno(int값)꺼내와서 if문으로 처리
         값은 여기서 꺼내올까 ? 컨트롤러에서 꺼내올까 ? 
         */
         
         return res;
      }

}