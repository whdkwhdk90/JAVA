package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/mapsms.do")
public class mapSms extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public mapSms() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String cd = request.getParameter("cd");
		if(cd.equals("mapsms")) {
//			String keyword = request.getParameter("keyword");
			dispatch("mapSms.jsp",request,response);
		}
	}


	private void dispatch(String url, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatch = request.getRequestDispatcher(url);
		dispatch.forward(request, response);
	}

	private void jsReponse(String url, String keyword,
			HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		out.println(				
				"<script>"
				+ "window.open('map.jsp?keyword="+ keyword + "','_blank','resizalbe=no,width=800,height=500,"
				+ "status=no,toolbar=no,menubar=no,location=no"
				+ "directories=no');"
				+ "</script>"
				);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	

}
