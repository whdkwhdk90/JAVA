package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.biz.MyBiz;
import com.dao.foodDao;
import com.dao.memberDao;
import com.dao.popularityDao;
import com.dto.SnsMemberDto;
import com.dto.foodDto;
import com.dto.memberDto;
import com.dto.popularityDto;

@WebServlet("/nation.do")
public class nation extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    public nation() {
        super();
    }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");
      response.setContentType("text/html; charset=UTF-8");
      
      
      HttpSession session = request.getSession(true);
      
      memberDto mdto = new memberDto();
      memberDto mb = (memberDto)session.getAttribute("rdto");
      
      SnsMemberDto sdto = new SnsMemberDto();
      SnsMemberDto smb = (SnsMemberDto)session.getAttribute("sdto");
      
      
      String cd = request.getParameter("cd");
      
      MyBiz biz = new MyBiz();
      
      foodDao fdao = new foodDao();
      memberDao mdao = new memberDao();
      popularityDao pdao = new popularityDao();
         
      
      if(cd.equals("nation")) {

         if( (session.getAttribute("rdto") == null || !request.isRequestedSessionIdValid())
         && (session.getAttribute("sdto") == null || !request.isRequestedSessionIdValid()) ){
            // 비회원 노출화면
            
              // 음식 리스트 받아오기(selectAll)
              List<foodDto> list = biz.selectAll();
              request.setAttribute("list", list);
              
              dispatch("nation.jsp", request, response);
            
         } else {
            // 회원 노출화면
            
            if (session.getAttribute("rdto") != null) {
               // 일반회원
               
                 // 음식 리스트 받아오기(selectAll)
                 List<foodDto> list = biz.selectAll();
                 request.setAttribute("list", list);
                 
                 // 좋아요 여부에 따른 화면 출력(회원번호 통해 음식번호 받아오기)
                 List<popularityDto> res = pdao.popYN(mb.getMno());
                 request.setAttribute("popList", res);
                 
                 for(int i=0; i<res.size(); i++) {
                    System.out.println("좋아요 fno: " + res.get(i).getFno());
                 }
                 
                 dispatch("nation.jsp", request, response);
               
            } else if(session.getAttribute("sdto") != null) {
               // sns회원
               
                  // 음식 리스트 받아오기(selectAll)
                  List<foodDto> list = biz.selectAll();
                  request.setAttribute("list", list);
                  
                  // 좋아요 여부에 따른 화면 출력(회원번호 통해 음식번호 받아오기)
                  List<popularityDto> res = pdao.popYN(smb.getMno());
                  request.setAttribute("popList", res);
                  
                  for(int i=0; i<res.size(); i++) {
                     System.out.println("좋아요 fno: " + res.get(i).getFno());
                  }
                  
                  dispatch("nation.jsp", request, response);
            }
            
         }
            
      } else if(cd.equals("heart_true")) {
         // 좋아요 
         System.out.println("좋아요 회원번호: "+mb.getMno());
         System.out.println("좋아요 회원나이: "+mb.getAge());
         System.out.println("좋아요 회원성별: "+mb.getGender());
         
         int fno = Integer.parseInt(request.getParameter("fno"));
         System.out.println(cd + " 좋아요 클릭!!!!!!! fno:" +fno+"\n");
         
         popularityDto dto = new popularityDto(fno, mb.getMno(), mb.getAge(), mb.getGender());
         int res = biz.insert(dto);
         
      } else if(cd.equals("heart_false")) {
         //좋아요 취소
         System.out.println("좋아요취소 회원번호: "+mb.getMno());
         System.out.println("좋아요취소 회원나이: "+mb.getAge());
         System.out.println("좋아요취소 회원성별: "+mb.getGender());
         
         int fno = Integer.parseInt(request.getParameter("fno"));
         System.out.println(cd + " 좋아요 취소!!!!!!! fno:" +fno+"\n");
         
         int res = biz.delete(fno, mb.getMno());
      } 
      
   }

   
   private void dispatch(String url, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      RequestDispatcher dispatch = request.getRequestDispatcher(url);
      dispatch.forward(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }

}