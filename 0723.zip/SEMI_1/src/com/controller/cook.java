package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.foodDao;
import com.dto.foodDto;

@WebServlet("/cook.do")
public class cook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public cook() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		String cd = request.getParameter("cd");

		foodDao dao = new foodDao();

		System.out.println("cd= " + cd);

		if (cd.equals("cook")) {
			List<foodDto> list = dao.selectAll();

			// System.out.println(list);

			request.setAttribute("list", list);
			dispatch("cook.jsp", request, response);

		} else if (cd.equals("detail")) {
			   int fno = Integer.parseInt(request.getParameter("fno"));
		         System.out.println("fno: " + fno);
		         foodDto dto = dao.selectdetil(fno);

		         String[] recipe = dto.getRecipe().split("\\n");
		         String[] jaeryo = dto.getIngredients().split("\\n");

		         request.setAttribute("jaeryo", jaeryo);
		         request.setAttribute("dto", dto);
		         request.setAttribute("recipe", recipe);
		         dispatch("recipedetail.jsp", request, response);
		}

		/// 7 - 70
		// 8 - 67
		// 9 - 64
		// 10 - 61
		// 11 - 59

	}
	private void dispatch(String url, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatch = request.getRequestDispatcher(url);
		dispatch.forward(request, response);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
