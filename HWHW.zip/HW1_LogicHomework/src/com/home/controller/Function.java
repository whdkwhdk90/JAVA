package com.home.controller;

import java.util.Scanner;

public class Function {

	Scanner sc = new Scanner(System.in);
	
		public void calculator() {
		
		System.out.print("첫번째 하나를 입력하시오 : ");
			int x1 = sc.nextInt();
		
		System.out.print("두번째 하나를 입력하시오 : ");
			int y1 = sc.nextInt();
			
		System.out.print("연산문자를 입력하시오 : ");
			char X1 = sc.next().charAt(0);
			int num = 0;
			
			if(X1 == '+') {
				num = x1+y1;
			}else if(X1 == '-'){
				num = x1-y1;
			}else if((X1 == 'x') ||(X1 == 'X')){
				num = x1*y1;
			}else {
				if(y1!=0) {
					num = x1/y1;
				}else {
					System.out.println("0으로 나눌 수 없습니다.");
				}
			}
			System.out.println(x1 + " " + X1 + " " + y1 + " = " + num);
			
		}

		public void totalCalculator() {
			
			int min, max;
			int tot = 0;
			System.out.print("첫번째 정수를 입력하시오 : ");
			int num1 = sc.nextInt();
			
			System.out.print("두번째 정수를 입력하시오 : ");
			int num2 = sc.nextInt();
			
			if(num1 > num2) {
				max = num1;
				min = num2;
				
			}else {
				max = num2;
				min = num1;
			}
			
			for(int i= min; i <= max; i ++) {
				tot += i;
			}
			
			System.out.println(min +"부터 "+max+"까지 정수들의 합계 : "+ tot);
			
			
		}

		public void profile() {
			
			
			
			
		}

		
		//// 입력을 받아서 하는건지 아니면 어디서 ????
		
		public void sungjuk() {
			
			char grade = ' ';
			String rege = "";
			System.out.print("이름을 입력하시오 : ");
			String name = sc.nextLine();
			
			System.out.print("학년을 입력하시오 : ");
			int level = sc.nextInt();
			
			System.out.print("반을 입력하시오 : ");
			int Class = sc.nextInt();
			
			System.out.print("번호를 입력하시오 : ");
			int num = sc.nextInt();
			
			System.out.print("성별을 입력하시오(M/F) : ");
			char gend = sc.next().charAt(0);
			
			rege = (gend =='M')?"남학생":"여학생";
			
			System.out.print("성적을 입력하시오 : ");
			double score = sc.nextDouble();
			if(score >=90) {
				grade = 'A';
			}else if(score >= 80) {
				grade = 'B';
			}else if(score >= 70) {
				grade = 'C';
			}else if(score >= 60) {
				grade = 'D';
			}else {
				grade = 'F';
			}
			
	System.out.print(level+"학년 "+ Class+ "반 "+num + "번 " +rege+" "+name+ "의 점수는 ");	
	System.out.printf("%.2f",score);		
	System.out.print("이고, "+grade+"학점입니다.\n");
		
		}

		public void printStarNumber() {
			
		System.out.print("정수 하나 입력: ");
		int num = sc.nextInt();
		
		if(num >0) {
			
			for(int i = 1; i <= num; i++) {
				for(int j =1; j <= i; j++) {
					if(i==j) {
						System.out.print(i);
					}else {
						System.out.print("*");
					}
	
				}System.out.println();
				
			}
			
		}else {
			System.out.println("양수가 아닙니다.");
		}
		
			
		}
		
		public void sumRandomNumber() {
			int sum = 0;
			int num = (int) ((Math.random()*100)+1);
			
			for(int i=1; i <= num; i++) {
				sum += i;
			}
			
		System.out.println("1부터 "+num+"까지의 합은 "+ sum+"입니다.");
			
		}

	
		//continue문은 사용을 어떻게 하는건지???
		public void continueGugudan() {

			System.out.print("단수 : ");
			int num = sc.nextInt();
			
			System.out.print("제외할 배수 : ");
			int num1 = sc.nextInt();
			
if(num >0) {
			System.out.println();
			for(int i =1; i <= 9; i++) {
				if(i != num1) {
					System.out.println(num+ "*"+ i +" = " +(num*i));
				}
					
				}
	
	}else {
				System.out.println("양수가 아닙니다.");
			}
			
			
			
			
		}

		public void shutNumber() {
			//랜덤함수 : 0부터 99까지 사용 가능
			// 1 ~ 100
		String answer ="";		
		int num1; 
		int num2; 

		do {
			System.out.print("수 하나를 입력하시오 : ");
			int numm = sc.nextInt();
			num1 = (int)(100*Math.random()/19)+1;
			num2 = (int)(100*Math.random()/19)+1;
			
			if(numm ==(num1+num2)) {		
				System.out.println("맞췄습니다.");
			}else {
				System.out.println("틀렸습니다.");
			}
			
			System.out.print("계속 하시겠습니까?(y/n) : ");
			answer = sc.next();
			
		}while(answer.contentEquals("Y") || answer.equals("y"));	
			
		}


}
